package Entities;

public class Categorie {

	private int idcategories;
	private Integer categorie_idcategories;
	private String description, tags;
	private String title_fr, title_en;

	public void setIdcategories(int idcategories) {
		this.idcategories = idcategories;
	}

	public int getIdcategories() {
		return idcategories;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setTitle_fr(String title_fr) {
		this.title_fr = title_fr;
	}

	public String getTitle_fr() {
		return title_fr;
	}

	public void setTitle_en(String title_en) {
		this.title_en = title_en;
	}

	public String getTitle_en() {
		return title_en;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getTags() {
		return tags;
	}

	public void setCategorie_idcategories(Integer categorie_idcategories) {
		this.categorie_idcategories = categorie_idcategories;
	}

	public Integer getCategorie_idcategories() {
		return categorie_idcategories;
	}
}
