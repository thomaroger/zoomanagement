package Language;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Configuration {

	// Nom du fichier de configuration
	private String strNomFichier = "Language.properties";
	// Chemin de la racine du programme
	private String strChemin;
	// Separateur du systeme de fichier
	private String strSeparateur;
	// Nom du dossier contenant les fichiers de configuration
	private static final String strDossierConfiguration = "src/Language";

	// Constructeurs :

	// Sans parametre
	public Configuration() {
		this.Initialise();
	}

	// Avec nom du fichier
	public Configuration(String p_strNomFichier) {
		this.setNomFichier(p_strNomFichier);
		this.Initialise();
	}

	// Initialisation
	private void Initialise() {
		this.setSeparateur(this.findSeparateur());
		this.setChemin(this.findChemin());
	}

	// Getters and Setters

	// Retourne le nom du dossier contenant les fichiers de configuration
	public static final String getDossierConfiguration() {
		return Configuration.strDossierConfiguration;
	}

	// Retourne le fichier
	public final String getNomFichier() {
		return this.strNomFichier;
	}

	// Defini le nom du fichier
	public void setNomFichier(String p_strNomFichier) {
		this.strNomFichier = p_strNomFichier;
	}

	// Retourne le chemin
	public final String getChemin() {
		return this.strChemin;
	}

	// Defini le Chemin
	public void setChemin(String p_strChemin) {
		this.strChemin = p_strChemin;
	}

	// Retourne le separateur
	public final String getSeparateur() {
		return this.strSeparateur;
	}

	// Defini le separateur
	public void setSeparateur(String p_strSeparateur) {
		this.strSeparateur = p_strSeparateur;
	}

	// Retourne le separateur correspondant au systeme de fichier
	// utiliser par le systeme d'explotation.
	public final String findSeparateur() {
		return System.getProperty("file.separator");
	}

	// Retourne le chemin courant correspondant au systeme de fichier
	// utiliser par le systeme d'explotation.
	public final String findChemin() {
		return System.getProperty("user.dir");
	}

	// Retourne le chemin complet vers le fichier
	public final String findCheminComplet() {
		return this.getChemin() + this.getSeparateur()
				+ Configuration.getDossierConfiguration()
				+ this.getSeparateur() + this.getNomFichier();
	}

	// Retourne la valeur correspondant a la clef
	public String getConfiguration(String p_strClef) {
		// Cree un objet Properties
		Properties oProperties = new Properties();

		// Cree un objet FileInputStream
		FileInputStream oFileInputStream;

		try {
			// Ouvre le fichier de configuration
			oFileInputStream = new FileInputStream(this.findCheminComplet());

			// Lit et charge les proprietes du fichier de configuration
			oProperties.load(oFileInputStream);

			// Ferme le fichier de configuration
			oFileInputStream.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Recupere la valeur de la propriete p_strClef
		return oProperties.getProperty(p_strClef);
	}

	// Retourne la valeur correspondant a la clef en specifiant le nom du
	// fichier de configuration
	public String getConfiguration(String p_strNomFichier, String p_strClef) {
		this.setNomFichier(p_strNomFichier);
		return this.getConfiguration(p_strClef);
	}

	// Stocke une paire clef/valeur avec un commentaire
	public void setConfigurationAvecCommentaire(String p_strClef,
			String p_strValeur, String p_strCommentaire) {
		// Cree un objet Properties
		Properties oProperties = new Properties();

		// Cree un objet FileInputStream
		FileInputStream oFileInputStream;

		// Cree un objet FileOutputStream
		FileOutputStream oFileOutputStream;

		try {
			// Ouvre le fichier de configuration
			oFileInputStream = new FileInputStream(this.findCheminComplet());

			// Lit et charge les proprietes du fichier de configuration
			oProperties.load(oFileInputStream);

			// Ferme le fichier de configuration
			oFileInputStream.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Ajjoute la valeur de la propriete p_strClef
		oProperties.setProperty(p_strClef, p_strValeur);

		try {
			// Ouvre le fichier de configuration
			oFileOutputStream = new FileOutputStream(this.findCheminComplet());

			// Stocke les proprietes dans le fichier de configuration
			oProperties.store(oFileOutputStream, p_strCommentaire);

			// Ferme le fichier de configuration
			oFileOutputStream.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// Stocke une paire clef/valeur avec un commentaire en specifiant le fichier
	public void setConfigurationAvecCommentaire(String p_strNomFichier,
			String p_strClef, String p_strValeur, String p_strCommentaire) {
		this.setNomFichier(p_strNomFichier);
		this.setConfigurationAvecCommentaire(p_strClef, p_strValeur,
				p_strCommentaire);
	}

	// Stocke une paire clef/valeur sans commentaire
	public void setConfiguration(String p_strClef, String p_strValeur) {
		this.setConfigurationAvecCommentaire(p_strClef, p_strValeur, "");
	}

	// Stocke une paire clef/valeur sans commentaire en specifiant le fichier
	public void setConfiguration(String p_strNomFichier, String p_strClef,
			String p_strValeur) {
		this.setNomFichier(p_strNomFichier);
		this.setConfiguration(p_strClef, p_strValeur);
	}

}
