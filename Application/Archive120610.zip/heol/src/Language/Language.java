package Language;

//Fichier de configuration et de langage
import java.util.Locale;
import java.util.ResourceBundle;

public final class Language {

	// Nom du fichier contenant les languages sans les codes iso
	private static final String STR_LANGUAGE_FILE = "Language";

	// Un objet ResourceBundle
	private static ResourceBundle oResourceBundle;

	// Getters and Setters

	// Retourne le langage actuel
	public static final String getCurrentLanguage() {
		return Language.oResourceBundle.getLocale().getLanguage();
	}

	// Retourne le pays actuel
	public static final String getCurrentCountry() {
		return Language.oResourceBundle.getLocale().getCountry();
	}

	// Selectionne un langage a partir de son nom et de son pays
	public static void setLanguage(String p_strLanguage, String p_strCountry) {
		// Cree un objet locale correspondant au langage
		Locale oLocale = new Locale(p_strLanguage, p_strCountry);

		// Selectionne le langage
		setLanguage(oLocale);
	}

	// Selectionne un langage a partir d'un objet Locale
	public static void setLanguage(Locale p_oLocale) {
		// Si l'objet locale n'est pas nul
		if (null != p_oLocale) {
			// Selectionne le langage
			oResourceBundle = ResourceBundle.getBundle(STR_LANGUAGE_FILE,
					p_oLocale);
		} else {
			// Selectionne le langage
			oResourceBundle = ResourceBundle.getBundle(STR_LANGUAGE_FILE);
		}
	}

	// Enregistre les modifications apportees au fichier de configuration
	public static void storeLanguage() {
		// Cree un objet Properties
		Configuration oConfig = new Configuration();

		// Sauvegarde le langage selectionne
		oConfig.setConfiguration("SelectedLanguage", Language
				.getCurrentLanguage());

		// Sauvegarde le pays selectionne
		oConfig.setConfiguration("SelectedCountry", Language
				.getCurrentCountry());
	}

	// Initialise le langage approprier
	public static void initializeLanguage() {
		// Cree un objet Properties
		Configuration oConfig = new Configuration();

		// Recupere la valeur de la propriete "FirstTime"
		// indiquant si c'est la premiere utilisation du logiciel.
		String strFirstTime = oConfig.getConfiguration("FirstTime");

		// Si c'est la premiere fois
		if (strFirstTime.equals("true")) {
			// Recupere le langage par defaut
			Locale oLocale;

			oLocale = Locale.getDefault();

			// Selectionne le langage par defaut selon les parametres de la
			// machine
			setLanguage(oLocale);

			// Enregistre les modifications dans le fichier de config
			Language.storeLanguage();

			// Modifie la valeur de FirstTime pour indiquer que l'application
			// a deja etait lancer
			oConfig.setConfiguration("FirstTime", "false");
		} else {
			// Sinon
			// Recupere la valeur de la propriete "Language"
			// indiquant le langage preferer ainsi que le pays preferer et
			// selectionne ce langage
			setLanguage(oConfig.getConfiguration("SelectedLanguage"), oConfig
					.getConfiguration("SelectedCountry"));

		}

	}

	// Retourne la chaine de caractere correspondante a la clef
	// dans le langage adequat
	public static String getAnInternationalizeString(String p_strKey) {
		// Retourne la valeur associee a la clef
		return oResourceBundle.getString(p_strKey);
	}

}