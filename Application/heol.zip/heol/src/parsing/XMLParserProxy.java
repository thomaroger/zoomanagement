package parsing;

public class XMLParserProxy implements parsing.XMLParser_PortType {
  private String _endpoint = null;
  private parsing.XMLParser_PortType xMLParser_PortType = null;
  
  public XMLParserProxy() {
    _initXMLParserProxy();
  }
  
  public XMLParserProxy(String endpoint) {
    _endpoint = endpoint;
    _initXMLParserProxy();
  }
  
  private void _initXMLParserProxy() {
    try {
      xMLParser_PortType = (new parsing.XMLParser_ServiceLocator()).getXMLParserPort();
      if (xMLParser_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xMLParser_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xMLParser_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xMLParser_PortType != null)
      ((javax.xml.rpc.Stub)xMLParser_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public parsing.XMLParser_PortType getXMLParser_PortType() {
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType;
  }
  
  public void unparseXML(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    xMLParser_PortType.unparseXML(arg0, arg1, arg2);
  }
  
  public java.lang.Object[][] xmlParserUser(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType.xmlParserUser(arg0, arg1);
  }
  
  public java.lang.Object[][] xmlParser(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType.xmlParser(arg0, arg1);
  }
  
  public java.lang.String xmlParserList(java.lang.String arg0) throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType.xmlParserList(arg0);
  }
  
  public java.lang.String[] recupTypeList() throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType.recupTypeList();
  }
  
  public java.lang.String[] recupTypeCategorie() throws java.rmi.RemoteException{
    if (xMLParser_PortType == null)
      _initXMLParserProxy();
    return xMLParser_PortType.recupTypeCategorie();
  }
  
  
}