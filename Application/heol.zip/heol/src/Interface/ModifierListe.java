package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import Entities.UnparsingXML;
import Language.Language;

public class ModifierListe extends JFrame implements ActionListener, WindowListener {

	protected JPanel pnlConteneur_main;
	protected JButton btnModifier;
	protected JLabel lblTitreListe, lblTagListe, lblDescriptionListe;
	protected JTextField txtTitreListe;
	protected JTextArea txtTagListe, txtDescriptionListe;
	protected JScrollPane ascenseur, ascenseur2;

	// Utilisateur courant
	protected Hashtable<String, String> userC;

	private String listeAModif;

	public ModifierListe(String titre, Hashtable<String, String> user, String listeAModifier) {
		super(titre);

		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);

		// Utilisateur courant
		userC = user;

		// Liste a modifier
		listeAModif = listeAModifier;

		// Test existance du fichier
		File userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
		Document document = null;
		if (userFile.exists() == true) {
			// On crée une instance de SAXBuilder
			SAXReader sxr = new SAXReader();
			// On crée un nouveau document JDOM avec en argument le fichier XML
			// Le parsing est terminé ;)
			try {
				document = sxr.read(userFile);
				document.setXMLEncoding("UTF-8");
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// Utilisateur courant
		userC = user;

		// Conteneur principale
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// label titre liste
		lblTitreListe = new JLabel(Language.getAnInternationalizeString("addListe_lblTitreListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 3; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblTitreListe, contraintes);

		// texte titre liste
		String titreListe = UnparsingXML.xmlreaderElement(document, null, "title", listeAModif);
		txtTitreListe = new JTextField(titreListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 3; // ligne 0
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(txtTitreListe, contraintes);

		// label tag liste
		lblTagListe = new JLabel(Language.getAnInternationalizeString("addListe_lblTagListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 4; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblTagListe, contraintes);

		// Textarea tag liste
		String TagListe = UnparsingXML.xmlreaderElement(document, null, "tag", listeAModif);
		txtTagListe = new JTextArea(5, 20);
		txtTagListe.setText(TagListe);
		ascenseur = new JScrollPane(txtTagListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 4; // ligne 1
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 3; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur, contraintes);

		// label Description liste
		lblDescriptionListe = new JLabel(Language.getAnInternationalizeString("addListe_lblDescriptionListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 7; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblDescriptionListe, contraintes);

		// Textarea description liste
		String DesciptionListe = UnparsingXML.xmlreaderElement(document, null, "description", listeAModif);
		txtDescriptionListe = new JTextArea(5, 20);
		txtDescriptionListe.setText(DesciptionListe);
		ascenseur2 = new JScrollPane(txtDescriptionListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 7; // ligne 1
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 3; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur2, contraintes);

		// bouton valider
		btnModifier = new JButton(Language.getAnInternationalizeString("modifierListe_btnValider"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 10; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnModifier, contraintes);
		btnModifier.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 450);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);

	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		if (evt.getSource() == btnModifier) {
			// Test existance du fichier
			File userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
			// On crée une instance de SAXBuilder
			SAXReader sxr = new SAXReader();
			Document document = null;
			try {
				document = sxr.read(userFile);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			List<Node> nodes = document.selectNodes("//Listes/List");
			for (Node node : nodes) {
				if (node.valueOf("title").equals(listeAModif)) {
					Element list = (Element) node;
					Element title = list.element("title");
					title.setText(txtTitreListe.getText().toString());
					Element description = list.element("description");
					description.setText(txtDescriptionListe.getText().toString());
					Element tag = list.element("tag");
					tag.setText(txtTagListe.getText().toString());
				}
			}

			// création du fichier
			try {
				// FileWriter myFile = new FileWriter(new File("xml/liste-" +
				// userC.get("login").toString(); + ".xml"), true);
				FileWriter myFile = new FileWriter(new File("xml/liste-"
						+ userC.get("login").toString() + ".xml"));
				XMLWriter output = new XMLWriter(myFile);
				output.write(document);
				output.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}

			// Fermeture de la forme.
			JOptionPane.showMessageDialog(
							null,
							"Votre liste a bien été modifiée. Elle sera effective lors de la prochaine synchronisation.",
							"Information", JOptionPane.INFORMATION_MESSAGE);

			// Actualisation de l'accueil
			try {
				Accueil acc = new Accueil(userC);
				// fermeture de la fenetre
				this.dispose();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fenétre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour décharger la mémoire occupée par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}
}
