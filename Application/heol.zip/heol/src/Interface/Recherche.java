package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import Entities.UnparsingXML;
import Language.Language;

@SuppressWarnings("serial")
public class Recherche extends JFrame implements ActionListener, WindowListener {

	private JLabel lblRecherche, lblListe, lblItem;
	private JPanel pnlConteneur_main;
	private JButton btnRecherche, btnModifierListe, btnSupprimerListe,
			BtnDeleteItem, BtnModifyItem;
	private JList lstMesItems, lstChoixListe;
	private JTextField txtRecherche;
	private JScrollPane ascenseur, ascenseur2;

	// utilisateur courant
	private Hashtable<String, String> userC;
	private File userFile;

	// liste
	private DefaultListModel model, modelListe;
	private String[] options = {};
	private String typeListe = null;
	private String[] typedeListe = { "music", "picture", "movie", "bookmark",
			"envie", "recall", "document", "event", "directory" };

	public Recherche(Hashtable<String, String> user,
			DefaultListModel ResultatSearchListe,
			DefaultListModel ResultatSearchItem) throws DocumentException {
		// Titre de la fenetre
		super(Language.getAnInternationalizeString("Recherche_Title"));

		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);

		// Utilisateur courant
		userC = user;

		// Conteneur principal
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// Ajout du label Recherche
		lblRecherche = new JLabel(Language
				.getAnInternationalizeString("Accueil_Recherche"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblRecherche, contraintes);

		// Ajout de la textbox de recherche
		txtRecherche = new JTextField();
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(txtRecherche, contraintes);

		// Ajout bouton recherche
		btnRecherche = new JButton(Language
				.getAnInternationalizeString("Accueil_btnRecherche"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 2; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnRecherche, contraintes);
		btnRecherche.addActionListener(this);

		// Ajout label Liste
		lblListe = new JLabel(Language
				.getAnInternationalizeString("Accueil_lblListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 3; // ligne 2
		contraintes.gridwidth = 3; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblListe, contraintes);

		// Ajout de toutes liste dispo
		modelListe = new DefaultListModel();
		modelListe = ResultatSearchListe;
		lstChoixListe = new JList(modelListe);
		ascenseur = new JScrollPane(lstChoixListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 4; // ligne 1
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur, contraintes);
		lstChoixListe.addListSelectionListener(new choixListe());

		// Ajout du bouton pour modifier une liste
		btnModifierListe = new JButton(Language
				.getAnInternationalizeString("Accueil_btnModifier"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 9; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnModifierListe, contraintes);
		btnModifierListe.addActionListener(this);

		// Ajout du bouton pour supprimer une liste
		btnSupprimerListe = new JButton(Language
				.getAnInternationalizeString("Accueil_btnSupprimer"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 2; // colonne 2
		contraintes.gridy = 9; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnSupprimerListe, contraintes);
		btnSupprimerListe.addActionListener(this);

		// Ajout label item
		lblItem = new JLabel(Language
				.getAnInternationalizeString("Accueil_lblItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 10; // ligne 2
		contraintes.gridwidth = 3; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblItem, contraintes);

		// Ajout de la liste des items de la liste selectionnee
		model = new DefaultListModel();
		model = ResultatSearchItem;
		lstMesItems = new JList(model);
		ascenseur2 = new JScrollPane(lstMesItems);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 1
		contraintes.gridy = 11; // ligne 1
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur2, contraintes);
		lstMesItems.addListSelectionListener(new choixItem());

		// Ajout du bouton pour modifier un item
		BtnModifyItem = new JButton(Language
				.getAnInternationalizeString("Accueil_btnModifierItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 16; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(BtnModifyItem, contraintes);
		BtnModifyItem.addActionListener(this);

		// Ajout du bouton pour supprimer un item
		BtnDeleteItem = new JButton(Language
				.getAnInternationalizeString("Accueil_btnSupprimerItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 2; // colonne 2
		contraintes.gridy = 16; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(BtnDeleteItem, contraintes);
		BtnDeleteItem.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 555);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);

	}

	// Action des boutons, listes, etc
	public void actionPerformed(ActionEvent evt) {
		Document document = null;

		if (evt.getSource() == btnModifierListe) {
			if (lstChoixListe.getSelectedValue() != null) {
				ModifierListe modifieListe = new ModifierListe(
						Language
								.getAnInternationalizeString("Accueil_TitreModifierListe"),
						userC, lstChoixListe.getSelectedValue().toString());
				this.dispose();
			} else {
				JOptionPane.showMessageDialog(null,
						"Vous devez sélectionné une liste", "Information",
						JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == BtnModifyItem) {
			if (lstChoixListe.getSelectedValue() != null
					&& lstChoixListe.getSelectedValue() != null) {
				try {
					ModifierItem modifieItem = new ModifierItem(
							Language
									.getAnInternationalizeString("Accueil_TitreModifierItem"),
							userC, lstChoixListe.getSelectedValue().toString(),
							lstMesItems.getSelectedValue().toString());
					this.dispose();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null,
						"Vous devez sélectionné une liste et un item",
						"Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == btnSupprimerListe) {
			if (lstChoixListe.getSelectedValue() != null) {
				SAXReader sxr = new SAXReader();
				try {
					document = sxr.read(userFile);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Supression de la liste
				document = UnparsingXML.removeList(document, "title",
						lstChoixListe.getSelectedValue().toString());

				// Enregistrement dans le fichier xml
				try {
					// FileWriter myFile = new FileWriter(new File("liste-" +
					// userC.get("login").toString() + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-"
							+ userC.get("login").toString() + ".xml"));
					XMLWriter output = new XMLWriter(myFile);
					output.write(document);
					output.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}

				JOptionPane.showMessageDialog(null,
						"Votre liste a bien été supprimée", "Information",
						JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
				try {
					Accueil acc = new Accueil(userC);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null,
						"Vous devez sélectionné une liste", "Information",
						JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == BtnDeleteItem) {
			if (lstMesItems.getSelectedValue() != null
					&& lstChoixListe.getSelectedValue() != null) {
				SAXReader sxr = new SAXReader();
				try {
					document = sxr.read(userFile);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Supression de l'item
				document = UnparsingXML.removeItem(document, "title",
						lstMesItems.getSelectedValue().toString(), typeListe);
				// Enregistrement dans le fichier xml
				try {
					// FileWriter myFile = new FileWriter(new
					// File(userC.get("login").toString() + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-"
							+ userC.get("login").toString() + ".xml"));
					XMLWriter output = new XMLWriter(myFile);
					output.write(document);
					output.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}

				JOptionPane.showMessageDialog(null,
						"Votre item a bien été supprimé", "Information",
						JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
				try {
					Accueil acc = new Accueil(userC);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null,
						"Vous devez sélectionné une liste et un item",
						"Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == btnRecherche) {
			try {
				SAXReader reader = new SAXReader();
				try {
					userFile = new File("xml/liste-"
							+ userC.get("login").toString() + ".xml");
					document = reader.read(userFile);
				} catch (DocumentException ex) {
					System.out.println(ex);
				}
				// Recherche
				DefaultListModel rechercheListe = UnparsingXML.searchListe(
						document, txtRecherche.getText().toString());
				DefaultListModel rechercheItem = UnparsingXML.searchItem(
						document, txtRecherche.getText().toString(),
						typedeListe);

				Recherche search = new Recherche(userC, rechercheListe,
						rechercheItem);
				this.dispose();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	class choixListe implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			if (lstMesItems.getSelectedValue() == null) {
				/*
				 * test sur le listener du bouton : clic souris = true
				 * relachement = false ce qui entraine 2 appels de la fonction
				 * valueChanged donc test pour seulement é true
				 */
				boolean adjust = lstChoixListe.getValueIsAdjusting();

				if (adjust == true) {
					// initialisation du model
					model.clear();

					// Lecture du XML de l'utilisateur pour ces listes
					userFile = new File("xml/liste-"
							+ userC.get("login").toString() + ".xml");
					if (userFile.exists() == true) {
						SAXReader sxr = new SAXReader();
						Document document = null;
						try {
							document = sxr.read(userFile);
						} catch (DocumentException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						// Récupération du nom du model
						if (lstChoixListe.getSelectedValue() != null) {
							typeListe = UnparsingXML
									.selectCategorie(document, lstChoixListe
											.getSelectedValue().toString());
							typeListe = capitalize(typeListe);

							options = UnparsingXML.xmlreaderItem(document,
									typeListe, "title", lstChoixListe
											.getSelectedValue().toString());
							for (int i = 0; i < options.length; i++) {
								model.addElement(options[i]);
							}
						}
					}
				}
			}
		}
	}

	class choixItem implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			// initialisation du model
			modelListe.clear();

			/*
			 * test sur le listener du bouton : clic souris = true relachement =
			 * false ce qui entraine 2 appels de la fonction valueChanged donc
			 * test pour seulement é true
			 */
			boolean adjust = lstMesItems.getValueIsAdjusting();

			if (adjust == false) {
				// Lecture du XML de l'utilisateur pour ces listes
				userFile = new File("xml/liste-"
						+ userC.get("login").toString() + ".xml");
				if (userFile.exists() == true) {
					SAXReader sxr = new SAXReader();
					Document document = null;
					try {
						document = sxr.read(userFile);
					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					// Récupération du nom du model
					if (lstMesItems.getSelectedValue() != null) {
						options = UnparsingXML.nomListe(document, typedeListe,
								lstMesItems.getSelectedValue().toString());
						for (int i = 0; i < options.length; i++) {
							modelListe.addElement(options[i]);
						}
					}
				}
			}
		}
	}

	public static String capitalize(String s) {
		if (s.length() == 0)
			return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fenétre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour décharger la mémoire occupée par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
