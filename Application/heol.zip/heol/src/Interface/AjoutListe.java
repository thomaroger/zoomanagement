package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import Language.Language;

public class AjoutListe extends JFrame implements ActionListener,
WindowListener {

	protected JComboBox ListeItem;
	protected JPanel pnlConteneur_main;
	protected JButton btnValider;
	protected JComboBox cmbCategorie;
	protected JLabel lblTitreListe, lblTagListe, lblDescriptionListe;
	protected JTextField txtTitreListe;
	protected JTextArea txtTagListe, txtDescriptionListe;
	protected JScrollPane ascenseur, ascenseur2;

	// Utilisateur courant
	private Hashtable<String, String> userC;

	private String[] liste;
	private String[] categorie;

	public AjoutListe(String titre, Hashtable<String, String> user)
	throws RemoteException {
		super(titre);

		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);

		// Utilisateur courant
		userC = user;

		// Recuperation de la liste de liste
		try {
			InputStream ips = new FileInputStream("config/typeListe.txt");
			InputStreamReader ipsr = new InputStreamReader(ips);
			BufferedReader br = new BufferedReader(ipsr);
			String ligne;
			int i = 0;
			int j = 0;
			while ((ligne = br.readLine()) != null) {
				j++;
			}
			br.close();

			ips = new FileInputStream("config/typeListe.txt");
			ipsr = new InputStreamReader(ips);
			br = new BufferedReader(ipsr);
			liste = new String[j];
			while ((ligne = br.readLine()) != null) {
				liste[i] = ligne;
				i++;
			}
			br.close();
		} catch (Exception e) {

		}
		// Recuperation de la liste de categorie
		try {
			InputStream ips = new FileInputStream("config/typeCategorie.txt");
			InputStreamReader ipsr = new InputStreamReader(ips);
			BufferedReader br = new BufferedReader(ipsr);
			String ligne;
			int i = 0;
			int j = 0;
			while ((ligne = br.readLine()) != null) {
				j++;
			}
			br.close();

			ips = new FileInputStream("config/typeCategorie.txt");
			ipsr = new InputStreamReader(ips);
			br = new BufferedReader(ipsr);
			categorie = new String[j];
			while ((ligne = br.readLine()) != null) 
			{
				categorie[i] = ligne;
				i++;
			}
			br.close();
		} catch (Exception e) {

		}

		// Conteneur principale
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// Ajout combobox liste
		ListeItem = new JComboBox(liste);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(ListeItem, contraintes);

		// Combobox de categorie
		cmbCategorie = new JComboBox(categorie);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 1; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(cmbCategorie, contraintes);

		// label titre liste
		lblTitreListe = new JLabel(Language.getAnInternationalizeString("addListe_lblTitreListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 3; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblTitreListe, contraintes);

		// texte titre liste
		txtTitreListe = new JTextField();
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 3; // ligne 0
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(txtTitreListe, contraintes);

		// label tag liste
		lblTagListe = new JLabel(Language.getAnInternationalizeString("addListe_lblTagListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 4; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblTagListe, contraintes);

		// Textarea tag liste
		txtTagListe = new JTextArea(5, 20);
		ascenseur = new JScrollPane(txtTagListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 4; // ligne 1
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 3; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur, contraintes);

		// label Description liste
		lblDescriptionListe = new JLabel(Language.getAnInternationalizeString("addListe_lblDescriptionListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 7; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblDescriptionListe, contraintes);

		// Textarea description liste
		txtDescriptionListe = new JTextArea(5, 20);
		ascenseur2 = new JScrollPane(txtDescriptionListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 7; // ligne 1
		contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 3; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur2, contraintes);

		// bouton valider
		btnValider = new JButton(Language.getAnInternationalizeString("addListe_btnValider"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 10; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnValider, contraintes);
		btnValider.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 450);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2, (screen.height - this.getSize().height) / 2);

	}

	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource() == btnValider) {

			// Test existance du fichier
			File userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
			Document document = null;
			if (userFile.exists() == true) {
				// On cr�e une instance de SAXBuilder
				SAXReader sxr = new SAXReader();
				// On cr�e un nouveau document JDOM avec en argument le fichier
				// XML
				// Le parsing est termin�
				try {
					document = sxr.read(userFile);
					document.setXMLEncoding("UTF-8");
					// On initialise un nouvel �l�ment racine avec l'�l�ment
					// racine du document.
					Element racine = document.getRootElement();
					// cr�ation �l�ment "List"
					Element typeListeElement = racine.addElement("List");
					// Cr�ation des �l�ments caract�risant la liste
					Element permission = typeListeElement.addElement("permission");
					permission.addText("1");
					Element nomModel = typeListeElement.addElement("nomModel");
					nomModel.addText(ListeItem.getSelectedItem().toString().toLowerCase());
					Element status = typeListeElement.addElement("status");
					status.addText("true");
					Element idListe = typeListeElement.addElement("idList");
					Element list_idList = typeListeElement.addElement("list_idList");
					Element nb_duplication = typeListeElement.addElement("nb_duplication");
					nb_duplication.addText("0");
					Element nb_view = typeListeElement.addElement("nb_view");
					nb_view.addText("0");
					Element title = typeListeElement.addElement("title");
					title.addText(txtTitreListe.getText().toString());
					Element description = typeListeElement.addElement("description");
					description.addText(txtDescriptionListe.getText().toString());
					Element tag = typeListeElement.addElement("tag");
					tag.addText(txtTagListe.getText().toString());
					Element categorie_idcategories = typeListeElement.addElement("categorie_idcategories");
					categorie_idcategories.addText(String.valueOf(ListeItem.getSelectedIndex()));
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
			else 
			{
				// Création de liste en XML
				document = DocumentHelper.createDocument();
				document.setXMLEncoding("UTF-8");
				// Création élément racine
				Element racine = document.addElement("Listes");
				racine.addComment("Les listes de :" + userC.get("login").toString());
				// création élément "List"
				Element typeListeElement = racine.addElement("List");
				// Création des éléments caractérisant la liste
				Element permission = typeListeElement.addElement("permission");
				permission.addText("1");
				Element nomModel = typeListeElement.addElement("nomModel");
				nomModel.addText(ListeItem.getSelectedItem().toString().toLowerCase());
				Element status = typeListeElement.addElement("status");
				status.addText("true");
				Element idListe = typeListeElement.addElement("idList");
				Element list_idList = typeListeElement.addElement("list_idList");
				Element nb_duplication = typeListeElement.addElement("nb_duplication");
				nb_duplication.addText("0");
				Element nb_view = typeListeElement.addElement("nb_view");
				nb_view.addText("0");
				Element title = typeListeElement.addElement("title");
				title.addText(txtTitreListe.getText().toString());
				Element description = typeListeElement.addElement("description");
				description.addText(txtDescriptionListe.getText().toString());
				Element tag = typeListeElement.addElement("tag");
				tag.addText(txtTagListe.getText().toString());
				Element categorie_idcategories = typeListeElement.addElement("categorie_idcategories");
				categorie_idcategories.addText(String.valueOf(ListeItem.getSelectedIndex()));

				// Ajout de la dtd
				document.addDocType("liste", "", "liste.dtd");
			}
			// création du fichier
			try {
				// FileWriter myFile = new FileWriter(new File("xml/liste-" +
				// userC.get("login").toString() + ".xml"), true);
				FileWriter myFile = new FileWriter(new File("xml/liste-" + userC.get("login").toString() + ".xml"));
				OutputFormat outFormat = new OutputFormat();
				outFormat.setEncoding("UTF-8");
				XMLWriter output = new XMLWriter(myFile, outFormat);
				output.write(document);
				output.close();

			} 
			catch (IOException e) 
			{
				System.out.println(e.getMessage());
			}

			// Fermeture de la forme.
			JOptionPane.showMessageDialog(null, "Votre liste a bien été créée. Elle sera effective lors de la prochaine synchronisation.", "Information", JOptionPane.INFORMATION_MESSAGE);

			// Actualisation de l'accueil
			try {
				Accueil acc = new Accueil(userC);
				// fermeture fenetre
				this.dispose();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fenêtre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour décharger la mémoire occupée par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}
}
