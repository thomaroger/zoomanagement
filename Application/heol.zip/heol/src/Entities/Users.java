package Entities;

public class Users {

	protected int idUser;
	private int privilege;
	private int status;
	private int online;
	protected String login, password, mail, ip;
	private String token;

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int id) {
		this.idUser = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String l) {
		this.login = l;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String l) {
		this.password = l;
	}

	public String getEmail() {
		return mail;
	}

	public void setEmail(String l) {
		this.mail = l;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String l) {
		this.ip = l;
	}

	public void setOnline(int online) {
		this.online = online;
	}

	public int getOnline() {
		return online;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getStatus() {
		return status;
	}

	public void setPrivilege(int privilege) {
		this.privilege = privilege;
	}

	public int getPrivilege() {
		return privilege;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getToken() {
		return token;
	}

}