//fichier crée par le WS necessaire pour le client
/*
http://localhost:8080/HeolWS/XMLParser?wsdl
 */
package parsing;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import java.util.Iterator;
import java.util.List;
import javax.jws.WebMethod;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.jdom.Document;
import org.dom4j.io.SAXReader;

import org.hibernate.*;
import org.hibernate.exception.JDBCConnectionException;

import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import utils.HibernateUtil;

/**
 *
 * @author etudiant
 */
@WebService(serviceName = "XMLParser")
public class XMLParser {

    /**
     * Methode de mise a jour du XML vers la base
     * @param monXML : String contenant tout le XML
     * @param deleted : String qui contient les listes ou les items
     */
    @WebMethod(operationName = "UnparseXML")
    public void UnparseXML(String idUser, String monXML, String deleted) {
        Session session = HibernateUtil.currentSession();

        //conversion String en fichier
        File file = new File(idUser + ".xml");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
        } catch (IOException ex) {
            Logger.getLogger(XMLParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter fichierSortie = new PrintWriter(bw);
        fichierSortie.println(monXML);
        fichierSortie.close();

        //lecture fichier avec jdom...
        SAXReader sxr = new SAXReader();
        org.dom4j.Document document = null;
        try {
            document = sxr.read(file);
            //(a test) ou :
            //document = sxr.read(monXML);
        } catch (DocumentException ex) {
            Logger.getLogger(XMLParser.class.getName()).log(Level.SEVERE, null, ex);
        }

        //insert or update if exists sur les listes
        String[][] listes = xmlreaderListe(document);
        for (int i = 0; i < listes.length; ++i) {
            String val = "";
            String val2 = "";
            boolean haveId = false;
            //créer les valeurs des champ a update selon leur type (string ou int)
            for (int j = 0; j < listes[i].length; ++j) {
                if (j == 3) {//si on est sur le champ id
                    haveId = (listes[i][j] != null || !listes[i][j].equals("")) ? true : false;
                    //si on a un id on met le champ sinon non
                    if (!haveId) {
                        continue;
                    }
                }
                val += j < 3 ? "\"" + listes[i][j] + "\"," : listes[i][j] + ",";
            }
            val = val.substring(0, val.length() - 1); //vire la derniere virgule...
            String req = "INSERT INTO list"
                    + " (title, description, tag, " + (haveId ? "idList," : " ") + "list_idList, nb_duplication, nb_view, categorie_idcategories, status)"
                    + " VALUES(" + val + ")"
                    + " ON DUPLICATE KEY UPDATE title=VALUES(title), description=VALUES(description), tag=VALUES(tag),"
                    + (haveId ? " idList=VALUES(idList), " : " ") + "list_idList=VALUES(list_idList), nb_duplication=VALUES(nb_duplication),"
                    + " nb_view=VALUES(nb_view), categorie_idcategories=VALUES(categorie_idcategories), status=VALUES(status)";
            
            //execution de la requete
            try {
                Transaction tx = session.beginTransaction();
                session.createSQLQuery(req).executeUpdate();
                if(!haveId)
                    session.createSQLQuery("insert into user_has_list (user_idUser,list_idList) values('"+idUser+"',(SELECT idList FROM `list` ORDER BY idList desc Limit 1))").executeUpdate();
                tx.commit();
            } catch (HibernateException e) {
                e.printStackTrace();
            }

        }

        //insert or update sur les items
        String[][][] items = xmlreaderItem(document);
        for (int i = 0; i < items.length; ++i) {
            String[] champs = champName(i); //recupere les noms des champs et de la table
            for (int j = 0; j < items[i].length; ++j) {
                String val = "";
                for (int k = 0; k < items[i][j].length; ++k) {
                    val += "\'" + items[i][j][k].replace("\'", "\'\'") + "\',";
                }
                val = val.substring(0, val.length() - 1); //vire la derniere virgule...
                String req = "INSERT INTO " + champs[0]
                        + ") VALUES(" + val + ")"
                        + " ON DUPLICATE KEY UPDATE " + champs[1];

                //execution de la requete
                try {
                    Transaction tx = session.beginTransaction();
                    session.createSQLQuery(req).executeUpdate();
                    tx.commit();
                } catch (HibernateException e) {
                    e.printStackTrace();
                }
            }
        }



        //delete des items selon param "deleted"
        String[] del = deleted.split(" ");
        if (del.length > 1) {
            Transaction tx = session.beginTransaction();

            for (int i = 0; i < del.length; ++i) {
                String req = "delete from " + del[i] + " where item_idItem=" + del[++i];
                session.createSQLQuery(req).executeUpdate();
                String req2 = "delete from item where idItem=" + del[i];
                session.createSQLQuery(req2).executeUpdate();
            }
            tx.commit();
        }
        HibernateUtil.closeSession();
    }

    /**
     * creer le contenu du xml user
     * @param query
     * @return
     */
    @WebMethod(operationName = "xmlParserUser")
    public Object[][] xmlParserUser(String login, String mdp) {
        Session session = HibernateUtil.currentSession();
        try {

            SQLQuery aze = session.createSQLQuery("select * from user where login = ? and password = ?;");
            aze.setString(0, login);
            aze.setString(1, mdp);
            SQLQuery column = session.createSQLQuery("SELECT COLUMN_NAME"
                    + " FROM INFORMATION_SCHEMA.COLUMNS"
                    + " WHERE table_name = 'user'"
                    + " AND table_schema = 'tootlist'");
            List userResult = aze.list();
            List userCols = column.list();

            Object[][] result = new Object[userResult.size() + 1][]; //+1 pour le nom des colonnes

            if (userResult != null && userCols != null) {
                //defini en [0] le nom des colonnes
                result[0] = userCols.toArray();
                //boucle ensuite sur toutes les lignes de la table
                int i = 1;
                for (Iterator it = userResult.iterator(); it.hasNext();) {
                    try {
                        result[i] = (Object[]) it.next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    i++;
                }
            }
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * creer le contenu du xml du reste
     * @param query
     * @param table
     * @return
     */
    @WebMethod(operationName = "xmlParser")
    public Object[][] xmlParser(String query, String table) {
        Session session = HibernateUtil.currentSession();
        try {

            SQLQuery aze = session.createSQLQuery(query);
            SQLQuery column = session.createSQLQuery("SELECT COLUMN_NAME"
                    + " FROM INFORMATION_SCHEMA.COLUMNS"
                    + " WHERE table_name = '" + table + "'");
            List queryResult = aze.list();
            //List items = queryResult.subList(queryResult.size()-1, queryResult.size());
            List userCols = column.list();

            Object[][] result = new Object[queryResult.size() + 1][]; //+1 pour le nom des colonnes

            if (queryResult != null && userCols != null) {
                //defini en [0] le nom des colonnes
                result[0] = userCols.toArray();
                //boucle ensuite sur toutes les lignes de la table
                int i = 1;
                for (Iterator it = queryResult.iterator(); it.hasNext();) {
                    try {
                        result[i] = (Object[]) it.next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    i++;
                }
            }
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @WebMethod(operationName = "xmlParserList")
    public String xmlParserList(String userId) {
        Session session = HibernateUtil.currentSession();
        try {

            //recupere les noms des colonnes
            SQLQuery column = session.createSQLQuery("SELECT COLUMN_NAME"
                    + " FROM INFORMATION_SCHEMA.COLUMNS"
                    + " WHERE table_name = 'list'");

            //List items = queryResult.subList(queryResult.size()-1, queryResult.size());
            List userCols = column.list();
            userCols.add("idItem");
            userCols.add("table_name");

            SQLQuery sel1 = session.createSQLQuery("SELECT l.*, i.idItem, m.table_name"
                    + " FROM list l, item i, user_has_list u, model m, type t"
                    + " WHERE u.list_idList = l.idList"
                    + " AND i.list_idList = l.idList"
                    + " AND m.idModel = t.model_id"
                    + " AND i.type_idtype = t.idtype"
                    + " AND m.isbase = 1"
                    + " AND user_idUser = ?");


            List queryResult = sel1.setString(0, userId).list();
            Object[][] result = new Object[2][];

            if (queryResult != null && userCols.size() > 2) {
                Element rootList = new Element("Listes");

                //defini en [0] le nom des colonnes
                result[0] = userCols.toArray();

                Integer idList = -1;
                Element listNode = new Element("List");
                //boucle ensuite sur toutes les lignes de la table
                for (Iterator it = queryResult.iterator(); it.hasNext();) {
                    try {
                        result[1] = (Object[]) it.next();

                        //creation de list => noeud
                        if (!idList.equals(new Integer(-1)) && !idList.equals((Integer) result[1][0])) {
                            listNode = new Element("List");
                        }

                        createNode(listNode, "nomModel", result[1][result[1].length - 1].toString());

                        for (int j = 0; j < result[1].length; ++j) {
                            if (j < 10) { //si c'est pas les derniere colonnes alors on ajoute le noeud sinon on fais la requete pour recuperer les items de la liste
                                //si c'est pas le meme id on cree une nouvelle list sinon on rajoute juste l'item
                                if (!idList.equals((Integer) result[1][0])) {
                                    createNode(listNode, result[0][j].toString(), result[1][j] == null ? null : result[1][j].toString());
                                }
                            } else if (j == 11) {
                                //créer la node de l'item
                                Element ItemNode = new Element(result[1][j] == null ? null : result[1][j].toString());
                                listNode.addContent(ItemNode);

                                //recup le nom des colonnes
                                SQLQuery column2 = session.createSQLQuery("SELECT COLUMN_NAME"
                                        + " FROM INFORMATION_SCHEMA.COLUMNS"
                                        + " WHERE table_name = ?"
                                        + " AND table_schema = 'tootlist'");

                                Object[][] lstColChamp = new Object[1][];
                                lstColChamp[0] = (Object[]) column2.setString(0, result[1][result[1].length - 1].toString()).list().toArray();

                                //recup le contenu de l'item
                                SQLQuery sel2 = session.createSQLQuery("select *"
                                        + " from " + result[1][result[1].length - 1]
                                        + " where item_idItem = ?");

                                //commun a toutes les listes de base sauf le repertoire tel
                                if (!"directory".equals(result[1][result[1].length - 1])) {
                                    sel2.addScalar("item_IdItem", Hibernate.INTEGER);
                                    sel2.addScalar("description", Hibernate.STRING);
                                    sel2.addScalar("title", Hibernate.STRING);
                                }
                                //spécificité selon les tables
                                if ("picture".equals(result[1][result[1].length - 1])) {
                                    sel2.addScalar("url", Hibernate.STRING);
                                    sel2.addScalar("url_new", Hibernate.STRING);
                                } else if ("movie".equals(result[1][result[1].length - 1])
                                        || "document".equals(result[1][result[1].length - 1])
                                        || "music".equals(result[1][result[1].length - 1])) {
                                    sel2.addScalar("url", Hibernate.STRING);
                                } else if ("bookmark".equals(result[1][result[1].length - 1])) {
                                    sel2.addScalar("link", Hibernate.STRING);
                                    sel2.addScalar("picture", Hibernate.STRING);
                                    sel2.addScalar("tags", Hibernate.STRING);
                                } else if ("event".equals(result[1][result[1].length - 1])) {
                                    sel2.addScalar("date_begin", Hibernate.DATE);
                                    sel2.addScalar("date_end", Hibernate.DATE);
                                    sel2.addScalar("location", Hibernate.STRING);
                                }

                                List queryResult2 = sel2.setString(0, result[1][result[1].length - 2].toString()).list();
                                for (int k = 0; k < lstColChamp[0].length; ++k) {
                                    createNode(ItemNode, lstColChamp[0][k].toString(), ((Object[]) queryResult2.get(0))[k].toString());
                                }
                            }
                        }

                    } catch (MappingException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //si idList = idList du precedent on ajoute pas encore
                    if (!idList.equals((Integer) result[1][0])) {
                        rootList.addContent(listNode);
                    }

                    //defini la derniere valeur de idList
                    idList = (Integer) result[1][0];
                }

                //Ecrit les données dans le fichier XML
                File file = new File(userId + "_list.xml");
                Document docUser = new Document(rootList);
                writeXML(docUser, file);

                String xmlListe = recupListe(file);

                return xmlListe;
            }

        } catch (JDBCConnectionException e) {
            System.err.println("Echec de la connexion a la BDD");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @WebMethod(operationName = "recupTypeList")
    public String[] recupTypeList() {
        Session session = HibernateUtil.currentSession();
        SQLQuery sel1 = session.createSQLQuery("SELECT table_name from model where isbase = 1");
        List Liste = sel1.list();

        String[] TypeListe = new String[Liste.size()];
        for (int i = 0; i < Liste.size(); i++) {
            TypeListe[i] = Liste.get(i).toString();
        }

        return TypeListe;
    }

    @WebMethod(operationName = "recupTypeCategorie")
    public String[] recupTypeCategorie() {
        Session session = HibernateUtil.currentSession();
        SQLQuery sel1 = session.createSQLQuery("SELECT title_fr from categorie");
        List Categorie = sel1.list();

        String[] TypeCategorie = new String[Categorie.size()];
        for (int i = 0; i < Categorie.size(); i++) {
            TypeCategorie[i] = Categorie.get(i).toString();
        }

        return TypeCategorie;
    }

    private String recupListe(File f) throws FileNotFoundException, IOException {
        String liste = "";
        String ligne = "";

        InputStream ips = new FileInputStream(f);
        InputStreamReader ipsr = new InputStreamReader(ips, "utf8");
        BufferedReader br = new BufferedReader(ipsr);

        //DataInputStream lecteur = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));

        try {
            int i = 0;
            while ((ligne = br.readLine()) != null) {
                if (i == 1) {
                    liste += "<!DOCTYPE liste SYSTEM 'liste.dtd'>";
                }
                liste += ligne;
                System.out.println(ligne);
                i++;
            }
            /*while ((ligne = lecteur.readUTF()) != null) {
            if (i == 1) {
            liste += "<!DOCTYPE liste SYSTEM 'liste.dtd'>";
            }
            liste += ligne;
            System.out.println(ligne);
            i++;
            }*/
        } catch (IOException ex) {
            Logger.getLogger(XMLParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        br.close();

        return liste;
    }

    private void writeXML(Document doc, Object outWriterOrOutputOrFile) {
        FileOutputStream fout = null;
        try {
            Format form = Format.getPrettyFormat();
            form.setEncoding("UTF8");
            // if provided, force the output encoding (otherwise, it defaults to "UTF8")
            XMLOutputter outputter = new XMLOutputter(form);
            if (outWriterOrOutputOrFile instanceof OutputStream) {
                outputter.output(doc, (OutputStream) outWriterOrOutputOrFile);
            } else if (outWriterOrOutputOrFile instanceof Writer) {
                outputter.output(doc, (Writer) outWriterOrOutputOrFile);
            } else if (outWriterOrOutputOrFile instanceof File) {
                File f = (File) outWriterOrOutputOrFile;
                fout = new FileOutputStream(f);
                outputter.output(doc, fout);
                fout.close();
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (fout != null) {
                try {
                    fout.close();
                } catch (Exception ee) {
                }
            }
        }
    }

    private void createNode(Element parentNode, String Noeud, String text) {
        Element node = new Element(Noeud);
        node.setText(text);
        parentNode.addContent(node);
    }

    @SuppressWarnings({"unchecked", "unused", "static-access"})
    private String[][] xmlreaderListe(org.dom4j.Document document) {
        List<Node> nodes;
        nodes = document.selectNodes("//Listes/List");
        String[][] ListeNode = new String[nodes.size()][9];
        int i = 0;
        for (Node node : nodes) {
            ListeNode[i][0] = node.valueOf("title");
            ListeNode[i][1] = node.valueOf("description");
            ListeNode[i][2] = node.valueOf("tag");
            ListeNode[i][3] = node.valueOf("idList");
            ListeNode[i][4] = node.valueOf("list_idList");
            ListeNode[i][5] = node.valueOf("nb_duplication");
            ListeNode[i][6] = node.valueOf("nb_view");
            ListeNode[i][7] = node.valueOf("categorie_idcategories");
            ListeNode[i][8] = node.valueOf("status");
            i++;
        }
        return ListeNode;
    }

    private String[] champName(int numTable) {
        String[] tab = new String[2];
        switch (numTable) {
            case 0:
                tab[0] = "picture(item_idItem,description,title,url,url_new";
                tab[1] = "item_idItem=values(item_idItem),description=values(description),title=values(title),url=values(url),url_new=values(url_new)";
                break;
            case 1:
                tab[0] = "movie(item_idItem,description,title,url";
                tab[1] = "item_idItem=values(item_idItem),description=values(description),title=values(title),url=values(url)";
                break;
            case 2:
                tab[0] = "envie(item_idItem,description,title";
                tab[1] = "item_idItem=values(item_idItem),description=values(description),title=values(title)";
                break;
            case 3:
                tab[0] = "bookmark(item_idItem,title,link,description,picture,tags";
                tab[1] = "item_idItem=values(item_idItem),title=values(title),link=values(link),description=values(description),picture=values(picture),tags=values(tags)";
                break;
            case 4:
                tab[0] = "document(item_idItem,title,description,url";
                tab[1] = "item_idItem=values(item_idItem),title=values(title),description=values(description),url=values(url)";
                break;
            case 5:
                tab[0] = "event(item_idItem,date_begin,date_end,description,location,title";
                tab[1] = "item_idItem=values(item_idItem),date_begin=values(date_begin),date_end=values(date_end),description=values(description),location=values(location),title=values(title)";
                break;
            case 6:
                tab[0] = "music(item_idItem,description,title,url";
                tab[1] = "item_idItem=values(item_idItem),description=values(description),title=values(title),url=values(url)";
                break;
            case 7:
                tab[0] = "directory(item_idItem,address,business_phone,city,country,email,email2,firstname,home_phone,lastname,login,phone,postal_code,website";
                tab[1] = "item_idItem=values(item_idItem),address=values(address),business_phone=values(business_phone),city=values(city),country=values(country),email=values(email),"
                        + "email2=values(email2),firstname=values(firstname),home_phone=values(home_phone),lastname=values(lastname),login=values(login),phone=values(phone),"
                        + "postal_code=values(postal_code),website=values(website)";
                break;
            case 8:
                tab[0] = "todo(item_idItem,title,due_date,check,description,withdrawal";
                tab[1] = "item_idItem=values(item_idItem),title=values(title),due_date=values(due_date),check=values(check),description=values(description),withdrawal=values(withdrawal)";
                break;
            default:
                tab[0] = "";
                tab[1] = "";
                break;
        }
        return tab;
    }

    @SuppressWarnings({"unchecked", "unused"})
    private String[][][] xmlreaderItem(org.dom4j.Document document) {
        String[][][] ListeItems = new String[9][][]; //nombre de liste de base : 9

        List<Node> nodes = document.selectNodes("//Listes/List/picture");
        String[][] ListeNode0 = new String[nodes.size()][5]; //nb d'item du type, nb de champ du type d'item
        int i = 0;
        for (Node node : nodes) {
            ListeNode0[i][0] = node.valueOf("item_idItem");
            ListeNode0[i][1] = node.valueOf("description");
            ListeNode0[i][2] = node.valueOf("title");
            ListeNode0[i][3] = node.valueOf("url");
            ListeNode0[i][4] = node.valueOf("url_new");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/movie");
        String[][] ListeNode1 = new String[nodes.size()][4]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode1[i][0] = node.valueOf("item_idItem");
            ListeNode1[i][1] = node.valueOf("description");
            ListeNode1[i][2] = node.valueOf("title");
            ListeNode1[i][3] = node.valueOf("url");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/envie");
        String[][] ListeNode2 = new String[nodes.size()][3]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode2[i][0] = node.valueOf("item_idItem");
            ListeNode2[i][1] = node.valueOf("description");
            ListeNode2[i][2] = node.valueOf("title");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/bookmark");
        String[][] ListeNode3 = new String[nodes.size()][6]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode3[i][0] = node.valueOf("item_idItem");
            ListeNode3[i][1] = node.valueOf("title");
            ListeNode3[i][2] = node.valueOf("link");
            ListeNode3[i][3] = node.valueOf("description");
            ListeNode3[i][4] = node.valueOf("picture");
            ListeNode3[i][5] = node.valueOf("tags");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/document");
        String[][] ListeNode4 = new String[nodes.size()][4]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode4[i][0] = node.valueOf("item_idItem");
            ListeNode4[i][1] = node.valueOf("title");
            ListeNode4[i][2] = node.valueOf("description");
            ListeNode4[i][3] = node.valueOf("url");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/event");
        String[][] ListeNode5 = new String[nodes.size()][6]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode5[i][0] = node.valueOf("item_idItem");
            ListeNode5[i][1] = node.valueOf("date_begin");
            ListeNode5[i][2] = node.valueOf("date_end");
            ListeNode5[i][3] = node.valueOf("description");
            ListeNode5[i][4] = node.valueOf("location");
            ListeNode5[i][5] = node.valueOf("title");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/music");
        String[][] ListeNode6 = new String[nodes.size()][4]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode6[i][0] = node.valueOf("item_idItem");
            ListeNode6[i][1] = node.valueOf("description");
            ListeNode6[i][2] = node.valueOf("title");
            ListeNode6[i][3] = node.valueOf("url");
            i++;
        }

        nodes = document.selectNodes("//Listes/List/directory");
        String[][] ListeNode7 = new String[nodes.size()][14]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode7[i][0] = node.valueOf("item_idItem");
            ListeNode7[i][1] = node.valueOf("address");
            ListeNode7[i][2] = node.valueOf("business_phone");
            ListeNode7[i][3] = node.valueOf("city");
            ListeNode7[i][4] = node.valueOf("country");
            ListeNode7[i][5] = node.valueOf("email");
            ListeNode7[i][6] = node.valueOf("email2");
            ListeNode7[i][7] = node.valueOf("firstname");
            ListeNode7[i][8] = node.valueOf("home_phone");
            ListeNode7[i][9] = node.valueOf("lastname");
            ListeNode7[i][10] = node.valueOf("login");
            ListeNode7[i][11] = node.valueOf("phone");
            ListeNode7[i][12] = node.valueOf("postal_code");
            ListeNode7[i][13] = node.valueOf("website");

            i++;
        }

        nodes = document.selectNodes("//Listes/List/todo");
        String[][] ListeNode8 = new String[nodes.size()][6]; //nb d'item du type, nb de champ du type d'item
        i = 0;
        for (Node node : nodes) {
            ListeNode8[i][0] = node.valueOf("item_idItem");
            ListeNode8[i][1] = node.valueOf("title");
            ListeNode8[i][2] = node.valueOf("due_date");
            ListeNode8[i][3] = node.valueOf("check");
            ListeNode8[i][4] = node.valueOf("description");
            ListeNode8[i][5] = node.valueOf("withdrawal");
            i++;
        }


        ListeItems[0] = ListeNode0; //insertion des photos dans le tableau
        ListeItems[1] = ListeNode1;
        ListeItems[2] = ListeNode2;
        ListeItems[3] = ListeNode3;
        ListeItems[4] = ListeNode4;
        ListeItems[5] = ListeNode5;
        ListeItems[6] = ListeNode6;
        ListeItems[7] = ListeNode7;
        ListeItems[8] = ListeNode8;

        return ListeItems;
    }
}
/***************************
 * A faire...
 *
 * recup la BDD (hibernate...) et la foutre dans un fichier xml
 *
 * pour select de plusieurs valeurs, rÈecrire la methode xmlreader en mettant des tableaux ou listes
 *
 * recuperer toutes les valeurs grace a xmlreader et les balancer a la BDD
 * (suposition : si valeur deja existante alors exception donc faire
 * un try catch dans la boucle et laisser
 * passer l'erreur(affichage msg de non actualisation du site pour l'utilisateur?))
 ****************************/
