/**
 * XMLParser_ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package parsing;

public class XMLParser_ServiceLocator extends org.apache.axis.client.Service implements parsing.XMLParser_Service {

    public XMLParser_ServiceLocator() {
    }


    public XMLParser_ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public XMLParser_ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for XMLParserPort
    private java.lang.String XMLParserPort_address = "http://localhost:8080/HeolWS/XMLParser";

    public java.lang.String getXMLParserPortAddress() {
        return XMLParserPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String XMLParserPortWSDDServiceName = "XMLParserPort";

    public java.lang.String getXMLParserPortWSDDServiceName() {
        return XMLParserPortWSDDServiceName;
    }

    public void setXMLParserPortWSDDServiceName(java.lang.String name) {
        XMLParserPortWSDDServiceName = name;
    }

    public parsing.XMLParser_PortType getXMLParserPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(XMLParserPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getXMLParserPort(endpoint);
    }

    public parsing.XMLParser_PortType getXMLParserPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            parsing.XMLParserPortBindingStub _stub = new parsing.XMLParserPortBindingStub(portAddress, this);
            _stub.setPortName(getXMLParserPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setXMLParserPortEndpointAddress(java.lang.String address) {
        XMLParserPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (parsing.XMLParser_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                parsing.XMLParserPortBindingStub _stub = new parsing.XMLParserPortBindingStub(new java.net.URL(XMLParserPort_address), this);
                _stub.setPortName(getXMLParserPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("XMLParserPort".equals(inputPortName)) {
            return getXMLParserPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://parsing/", "XMLParser");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://parsing/", "XMLParserPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("XMLParserPort".equals(portName)) {
            setXMLParserPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
