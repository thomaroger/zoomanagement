package Entities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.util.Hashtable;

import javax.swing.JOptionPane;
import javax.xml.rpc.ServiceException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.jdom.JDOMException;

import Interface.Accueil;
import Interface.Index;

public class Identification {

	private boolean connection = false;
	@SuppressWarnings("unused")
	private Users user;
	private File userFile;

	@SuppressWarnings( { "unchecked", "static-access" })
	public Identification(Hashtable identifiant, Index login) throws UnsupportedEncodingException, DocumentException {
		// Session session = HibernateUtil.currentSession();
		try {

			String login_tmp = identifiant.get("login").toString();
			String password_tmp = identifiant.get("password").toString();
			MD5 chaine = new MD5();
			password_tmp = chaine.encode(password_tmp);

			/*
			 * Criteria criteria = session.createCriteria(Users.class);
			 * criteria.add(Restrictions.eq("email",login_tmp));
			 * criteria.add(Restrictions.eq("Password",password_tmp)); List
			 * userResult = criteria.list(); if(userResult !=null) { for
			 * (Iterator it = userResult.iterator() ; it.hasNext();) { Users
			 * result =(Users) it.next(); connection = true; user = result; } }
			 */

			SAXReader reader = new SAXReader();
			Document document = null;
			try 
			{
				userFile = new File("xml/info-"+ identifiant.get("login").toString() + ".xml");
				document = reader.read(userFile);
			} catch (DocumentException ex) {
				System.out.println(ex);
			}

			// si pas de fichier on le cr�e avec webservice
			if (userFile.exists() == false) {
				// cr�ation du xml user avec webservice
				ParsingXML.XMLParserUser(login_tmp, password_tmp);

				// cr�ation typeliste en txt
				parsing.XMLParser_Service service = new parsing.XMLParser_ServiceLocator();
				parsing.XMLParser_PortType port = null;

				try {
					port = service.getXMLParserPort();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					File f = new File("config/typeListe.txt");
					if (f.exists() == false) {
						f.createNewFile();
						FileWriter fw = new FileWriter(f);
						String[] liste = port.recupTypeList();
						for (int i = 0; i < liste.length; i++) {
							fw.write(liste[i].toString() + "\n");
						}
						fw.flush();
						fw.close();
					}
				} catch (IOException ex) {
					ex.printStackTrace();
				}

				// cr�ation ca�gorie liste en txt
				try {
					port = service.getXMLParserPort();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					File f = new File("config/typeCategorie.txt");
					if (f.exists() == false) {
						f.createNewFile();
						FileWriter fw = new FileWriter(f);
						String[] cat = port.recupTypeCategorie();
						for (int i = 0; i < cat.length; i++) {
							fw.write(cat[i].toString() + "\n");
						}
						fw.flush();
						fw.close();
					}
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}

			connection = UnparsingXML.connexion(login_tmp, password_tmp);

			// Connexion
			if (connection) 
			{

				// Si l'utlisateur se connecte on vide son fichier de suppression
				File myFile = new File("xml/delete-" + login_tmp + ".txt");
				//if(myFile.exists() == true)
				//{
					FileWriter f = new FileWriter(myFile, false);
					BufferedWriter sortie = new BufferedWriter(f);
					sortie.write("");
					sortie.close();
					//myFile.delete();
				//}

				document = reader.read(userFile);
				String idUser = UnparsingXML.idUser(document);
				String loginU = UnparsingXML.Login(document);
				try 
				{
					ParsingXML.XMLList(idUser, loginU);
				} 
				catch (JDOMException e) 
				{
					// TODO Auto-generated catch block
				}

				@SuppressWarnings("unused")
				Accueil acceuil = new Accueil(identifiant);
				login.dispose();

			} 
			else 
			{
				JOptionPane.showMessageDialog(null, "Connexion refusee", "Etat de la connexion", JOptionPane.ERROR_MESSAGE);
			} 

		} 
		catch (Exception e) 
		{
			System.out.println("Error : " + e);
			Accueil acceuil = new Accueil(identifiant);
			login.dispose();
		}

		// session.close();
	}
}
