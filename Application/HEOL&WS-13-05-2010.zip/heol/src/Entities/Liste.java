package Entities;

public class Liste {

	private int idList, list_idList, categorie_idcategories;
	private String title, description, tag;

	public void setIdList(int idList) {
		this.idList = idList;
	}

	public int getIdList() {
		return idList;
	}

	public void setList_idList(int list_idList) {
		this.list_idList = list_idList;
	}

	public int getList_idList() {
		return list_idList;
	}

	public void setCategorie_idcategories(int categorie_idcategories) {
		this.categorie_idcategories = categorie_idcategories;
	}

	public int getCategorie_idcategories() {
		return categorie_idcategories;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getTag() {
		return tag;
	}

}
