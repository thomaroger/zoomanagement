package Entities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.DefaultListModel;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

//SHOW VARIABLES LIKE 'char%';

//http://www.ibm.com/developerworks/xml/library/x-dom4j.html

public class UnparsingXML {

	public UnparsingXML(File myXML, String elementPath, String element) throws DocumentException, UnsupportedEncodingException {
		SAXReader sxr = new SAXReader();
		Document document = sxr.read(myXML);
		String[] aze = xmlreaderListe(document, elementPath, element);
		for (int i = 0; i < aze.length; i++) {
			System.out.println(aze[i]);
		}
	}

	@SuppressWarnings("unchecked")
	public static String[] xmlreaderListe(Document document, String elementPath, String element) throws UnsupportedEncodingException {
		List<Node> nodes;
		if (elementPath != null) {
			nodes = document.selectNodes("//Listes/List/" + elementPath);
		} else {
			nodes = document.selectNodes("//Listes/List");
		}
		String[] ListeNode = new String[nodes.size()];
		int i = 0;
		for (Node node : nodes) {
			if (node.valueOf("status").equals("true")) 
			{
				if(node.valueOf(element).toString() != null)
				{
					ListeNode[i] = node.valueOf(element).toString();
				}
				i++;
			}
		}
		return ListeNode;
	}

	@SuppressWarnings("unchecked")
	public static String[] xmlreaderItem(Document document, String elementPath, String element, String ElementaChercher) {
		List<Node> nodeItem = null;
		String[] ListeNode = null;
		nodeItem = document.selectNodes("//Listes/List/" + elementPath);
		ListeNode = new String[nodeItem.size()];
		int i = 0;
		for (Node nodesItem : nodeItem) {
			Element racine = (Element) nodesItem;
			Element parent = racine.getParent();
			if (parent.elementText("title").equals(ElementaChercher)) {
				// Pour toutes les listes qui ne sont pas des directory
				if (!nodesItem.valueOf(element).isEmpty()) {
					ListeNode[i] = nodesItem.valueOf(element);
				}
				// si directory
				else 
				{
					ListeNode[i] = nodesItem.valueOf("lastname") + " " + nodesItem.valueOf("firstname");
				}
				i++;
			}

		}
		return ListeNode;
	}

	@SuppressWarnings("unchecked")
	public static String xmlreaderElement(Document document, String elementPath, String element, String ElementaChercher) {
		List<Node> nodes;
		if (elementPath != null) {
			nodes = document.selectNodes("//Listes/List/" + elementPath);
		} else {
			nodes = document.selectNodes("//Listes/List");
		}
		String elementRetour = null;
		for (Node node : nodes) {
			String name = node.valueOf("lastname") + " " + node.valueOf("firstname");
			if (node.valueOf("title").equals(ElementaChercher)) {
				elementRetour = node.valueOf(element);
			}
			// si directory
			else if(name.equals(ElementaChercher))
			{
				elementRetour = node.valueOf(element);
			}
			else 
			{
				elementRetour = node.valueOf("lastname") + " " + node.valueOf("firstname");
			}
		}
		return elementRetour;
	}

	@SuppressWarnings("unchecked")
	public static Document removeList(Document document, String element, String ElementaDelete) {
		List<Node> nodes;
		nodes = document.selectNodes("//Listes/List");
		/*
		 * for (Node node : nodes) {
		 * if(node.valueOf(element).equals(ElementaDelete)) {
		 * node.getParent().remove(node); document.normalize(); } }
		 */

		for (Node node : nodes) {
			if (node.valueOf(element).equals(ElementaDelete)) {
				Element list = (Element) node;
				Element status = list.element("status");
				status.setText("false");
				document.normalize();
			}
		}

		return document;
	}

	@SuppressWarnings("unchecked")
	public static Document removeItem(Document document, String element, String ElementaDelete, String ElementhPath) {
		List<Node> nodes;
		nodes = document.selectNodes("//Listes/List/" + ElementhPath);
		for (Node node : nodes) {
			if (node.valueOf(element).equals(ElementaDelete)) {
				node.getParent().remove(node);
				document.normalize();
			}
		}
		return document;
	}

	@SuppressWarnings("unchecked")
	public static String selectCategorie(Document document, String Liste) {
		List<Node> nodes;
		nodes = document.selectNodes("//Listes/List");
		String typelist = null;
		for (Node node : nodes) {
			if (node.valueOf("title").equals(Liste)) {
				typelist = node.valueOf("nomModel");
			}
		}
		return typelist;
	}

	@SuppressWarnings("unchecked")
	public static DefaultListModel searchListe(Document document, String MotAChercher) {
		DefaultListModel tabResult = new DefaultListModel();
		boolean isSearch;
		List<Node> nodes;
		nodes = document.selectNodes("//Listes/List");
		CharSequence char0 = MotAChercher;
		for (Node node : nodes) {
			isSearch = false;

			if (node.valueOf("title").contains(char0)) {
				isSearch = true;
			} else if (node.valueOf("nomModel").contains(char0)) {
				isSearch = true;
			} else if (node.valueOf("description").contains(char0)) {
				isSearch = true;
			} else if (node.valueOf("tag").contains(char0)) {
				isSearch = true;
			}

			if (isSearch == true) {
				tabResult.addElement(node.valueOf("title"));
			}
		}
		return tabResult;
	}

	@SuppressWarnings("unchecked")
	public static DefaultListModel searchItem(Document document, String MotAChercher, String[] TypeListe) {
		DefaultListModel tabResult = new DefaultListModel();
		boolean isSearch;
		List<Node> nodes;
		CharSequence char0 = MotAChercher;
		for (int i = 0; i < TypeListe.length; i++) {
			nodes = document.selectNodes("//Listes/List/" + TypeListe[i].toString());
			for (Node node : nodes) {
				isSearch = false;
				if (node.valueOf("title").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("description").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("location").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("tag").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("tags").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("link").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("picture").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("url").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("login").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("address").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("city").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("country").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("email").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("firstname").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("lastname").contains(char0)) {
					isSearch = true;
				} else if (node.valueOf("email2").contains(char0)) {
					isSearch = true;
				}

				if (isSearch == true) {
					tabResult.addElement(node.valueOf("title"));
				}
			}
		}

		return tabResult;
	}

	@SuppressWarnings("unchecked")
	public static boolean connexion(String loginTmp, String passwordTmp) throws DocumentException {
		boolean isLogin = false;
		SAXReader sxr = new SAXReader();
		File userFile = new File("xml/info-" + loginTmp + ".xml");
		if (userFile.exists() == true) 
		{
			Document document = sxr.read(userFile);
			List<Node> nodes;
			nodes = document.selectNodes("//user");
			for (Node node : nodes) {
				if (node.valueOf("login").equals(loginTmp) && node.valueOf("password").equals(passwordTmp))
				{
					isLogin = true;
				}
			}
		}
		return isLogin;
	}

	public static boolean isDate(String Date) {
		boolean isValid = false;

		isValid = Pattern.matches("(0[1-9]|1[012])([\\/ /.])(0[1-9]|[12][0-9]|3[01])\\2(19|20)\\d\\d", Date);
		return isValid;

	}

	public static boolean isURL(String URL) {
		boolean isValid = false;

		isValid = Pattern.matches("^(http://|https://){0,1}[A-Za-z0-9][A-Za-z0-9\\-\\.]+[A-Za-z0-9]\\.[A-Za-z]{2,}[\43-\176]*$", URL);
		return isValid;
	}

	// R�cup�ration du titre de la liste � partir de l'item
	@SuppressWarnings("unchecked")
	public static String[] nomListe(Document document, String[] TypeListe, String nomItem) {
		List<Node> nodes;
		String[] typelist = {};
		typelist = new String[1];
		int j = 0;
		for (int i = 0; i < TypeListe.length; i++) {
			nodes = document.selectNodes("//Listes/List/" + TypeListe[i].toString());
			for (Node node : nodes) {
				if (node.valueOf("title").equals(nomItem)) {
					Element racine = (Element) node;
					Element parent = racine.getParent();
					typelist[j] = parent.valueOf("title").toString();
					j++;
				}
			}
		}
		return typelist;
	}

	@SuppressWarnings("unchecked")
	public static String idUser(Document document) {
		List<Node> nodes;
		nodes = document.selectNodes("//user");
		String idUser = null;
		for (Node node : nodes) {
			idUser = node.valueOf("idUser");
		}
		return idUser;
	}

	@SuppressWarnings("unchecked")
	public static String Login(Document document) {
		List<Node> nodes;
		nodes = document.selectNodes("//user");
		String login = null;
		for (Node node : nodes) {
			login = node.valueOf("login");
		}
		return login;
	}

	// Fonction cr�ant un fichier pour un user pour ces items deletes
	@SuppressWarnings("unchecked")
	public static void fichierDelete(Document document, String element, String ElementaDelete, String ElementhPath, Hashtable<String, String> userC) throws IOException {
		List<Node> nodes;
		nodes = document.selectNodes("//Listes/List/" + ElementhPath);
		String idItem = null;

		for (Node node : nodes) {
			if (node.valueOf(element).equals(ElementaDelete)) 
			{
				@SuppressWarnings("unused")
				Element list = (Element) node;
				idItem = node.valueOf("item_idItem");
			}
		}

		FileWriter myFile = new FileWriter(new File("xml/delete-" + userC.get("login").toString() + ".txt"), true);
		BufferedWriter sortie = new BufferedWriter(myFile);
		sortie.write(ElementhPath + " " + idItem.toString() + "\n");
		sortie.close();
	}

	/*-----------------------------------------------------------------------*/
	/**
	 * Cas d'une seule info demandee (eclipse)
	 * 
	 * @param document
	 * @param elementPath
	 * @param element
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String[] xmlReader(org.dom4j.Document document, String elementPath, String element) {
		List<Node> nodes = document.selectNodes("//Listes/List" + elementPath);
		String[] studentId = new String[nodes.size()];
		int i = 0;
		for (Node node : nodes) {
			studentId[i] = node.valueOf(element);
			i++;
		}
		return studentId;
	}

}
