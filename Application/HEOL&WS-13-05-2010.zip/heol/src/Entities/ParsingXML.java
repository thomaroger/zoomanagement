package Entities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.rmi.RemoteException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.rpc.ServiceException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.xml.sax.SAXException;

public class ParsingXML {



    /**
     * Methode d'ecriture du fichier xml User
     * @param resultDB
     */
    public static void XMLParserUser(String login, String PassWord){

        //Connexion au webservice et recupere le user
        parsing.XMLParser_Service service = new parsing.XMLParser_ServiceLocator();
        parsing.XMLParser_PortType port = null;
        try {
            port = service.getXMLParserPort();
        } catch (ServiceException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Object [][] resultDB = null;
        try {
            resultDB = port.xmlParserUser( login, PassWord);
        } catch (RemoteException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //export BDD => XML user
        Element rootUser = new Element("user");
        if(resultDB !=null)
            for(int i=0;i<resultDB[0].length;++i)
                createNode(rootUser, resultDB[0][i].toString(),resultDB[1][i] == null?null:resultDB[1][i].toString());

        //Ecrit les donn�es dans le fichier XML
        File file = new File("xml/info-" + login + ".xml");
        Document docUser = new Document(rootUser);
        writeXML(docUser,file);

    }

    /**
     * Methode d'ecriture du fichier xml List
     * @param resultDB
     * @throws IOException 
     * @throws JDOMException 
     * @throws SAXException 
     * @throws ParserConfigurationException 
     */
    public static File file;
    
    public static boolean XMLList(String idUser, String login) throws IOException, JDOMException, ParserConfigurationException, SAXException{
        //Connexion au webservice et recupere les liste
        parsing.XMLParser_Service service = new parsing.XMLParser_ServiceLocator();
        parsing.XMLParser_PortType port = null;

        try
        {
            port = service.getXMLParserPort();
        }
        catch (ServiceException e) 
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try 
        {
            // Recupere les listes user sous forme de string (par le WS)
            String Liste = port.xmlParserList(idUser);
            //Ecrit les donn�es dans le fichier XML
            file = new File("xml/liste-" + login + ".xml");        
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter fichierSortie = new PrintWriter(bw); 
            fichierSortie.println(Liste);
            fichierSortie.close();
        } 
        catch (RemoteException e) 
        {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        	if(file.exists() == true)
        	{
        		return true;	
        	}
        	else
        	{
        		return false;
        	}
        		
        }
        return true;
    }

    /**
     * Fonction de creation de noeud enfant avec du texte dedans
     * @param parentNode
     * @param Noeud
     * @param text
     */
    private static void createNode(Element parentNode, String Noeud, String text) {
        Element node = new Element(Noeud);
        node.setText(text);
        parentNode.addContent(node);
    }

    /**
     * cr�e le fichier XML physiquement
     * @param doc
     * @param outWriterOrOutputOrFile
     */
    private static void writeXML( Document doc, Object outWriterOrOutputOrFile ) {
        FileOutputStream fout = null;
        try {
            Format form = Format.getPrettyFormat();
            form.setEncoding("UTF8");
            // if provided, force the output encoding (otherwise, it defaults to "UTF8")
            XMLOutputter outputter = new XMLOutputter(form);
            if (outWriterOrOutputOrFile instanceof OutputStream)
                outputter.output(doc, (OutputStream) outWriterOrOutputOrFile);
            else if (outWriterOrOutputOrFile instanceof Writer)
                outputter.output(doc, (Writer) outWriterOrOutputOrFile);
            else if (outWriterOrOutputOrFile instanceof File) {
                File f = (File) outWriterOrOutputOrFile;
                fout = new FileOutputStream(f);
                outputter.output(doc, fout);
                fout.close();
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (fout != null)
                try {
                    fout.close();
                } catch (Exception ee) {
                }
        }
    }
}