package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import Entities.UnparsingXML;
import Language.Language;

public class ModifierItem extends JFrame implements ActionListener,
		WindowListener {

	private JButton btnValider;
	private JLabel lblDateDebut, lblDateFin, lblDescription, lblUrl, lblTitre,
			lblTag, lblImage, lblLocation, lblHome_phone;
	private JLabel lblBusiness_phone, lblAddress, lblcountry, lblcity,
			lblEmail, lblEmail2, lblFirstname;
	private JLabel lblpostal_code, lbllastname, lbllogin, lblphone, lblWebsite;
	private JTextField txtDateDebut, txtDateFin, txtUrl, txtTitre, txtImage,
			txtLocation, txtHome_phone;
	private JTextField txtBusiness_phone, txtcountry, txtcity, txtEmail,
			txtEmail2, txtFirstname;
	private JTextField txtpostal_code, txtlastname, txtlogin, txtphone,
			txtWebsite;
	private JTextArea txtDescription, txtTag, txtAddress;
	private JScrollPane ascenseur;
	private JPanel pnlConteneur_main;

	// Utilisateur courant
	protected Hashtable<String, String> userC;

	private String[] liste;
	private String ListeSelectionne, typeListe, ItemSelect;

	private Document document = null;
	private File userFile;

	boolean Error = false;

	public ModifierItem(String titre, Hashtable<String, String> user,
			String ListeSelecte, String ItemSelectionne)
			throws DocumentException {
		super(titre);

		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);

		// Utilisateur courant
		userC = user;

		// Type de Liste selectionnee
		ListeSelectionne = ListeSelecte;
		// Item selectionne
		ItemSelect = ItemSelectionne;

		// Conteneur principale
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// Suppression des composants pr�sents sur la forme
		if (pnlConteneur_main.getComponentCount() > 0) {
			for (int i = 0; i < pnlConteneur_main.getComponentCount(); i++) {
				pnlConteneur_main.remove(i);
			}
		}

		// R�cup�ration du model de liste s�lectionn�e
		userFile = new File("xml/liste-" + userC.get("login").toString()
				+ ".xml");
		if (userFile.exists() == true) {
			SAXReader sxr = new SAXReader();
			document = sxr.read(userFile);
			typeListe = UnparsingXML.selectCategorie(document, ListeSelecte);
			// typeListe = Accueil.capitalize(typeListe);
		}

		// R�cup�ration des valeurs des champs � modifier
		String TagsItem = UnparsingXML.xmlreaderElement(document, typeListe, "tags", ItemSelect);
		String LocationItem = UnparsingXML.xmlreaderElement(document, typeListe, "location", ItemSelect);
		String TagItem = UnparsingXML.xmlreaderElement(document, typeListe, "tag", ItemSelect);
		String TitleItem = UnparsingXML.xmlreaderElement(document, typeListe, "title", ItemSelect);
		String DescriptionItem = UnparsingXML.xmlreaderElement(document, typeListe, "description", ItemSelect);
		String urlItem = UnparsingXML.xmlreaderElement(document, typeListe, "url", ItemSelect);
		String ImageItem = UnparsingXML.xmlreaderElement(document, typeListe, "picture", ItemSelect);
		String LinkItem = UnparsingXML.xmlreaderElement(document, typeListe, "link", ItemSelect);
		String DateDebutItem = UnparsingXML.xmlreaderElement(document, typeListe, "date_begin", ItemSelect);
		String DatefinItem = UnparsingXML.xmlreaderElement(document, typeListe, "date_end", ItemSelect);
		String address = UnparsingXML.xmlreaderElement(document, typeListe, "address", ItemSelect);
		String business_phone = UnparsingXML.xmlreaderElement(document, typeListe, "business_phone", ItemSelect);
		String city = UnparsingXML.xmlreaderElement(document, typeListe, "city", ItemSelect);
		String country = UnparsingXML.xmlreaderElement(document, typeListe, "country", ItemSelect);
		String email = UnparsingXML.xmlreaderElement(document, typeListe, "email", ItemSelect);
		String email2 = UnparsingXML.xmlreaderElement(document, typeListe, "email2", ItemSelect);
		String firstname = UnparsingXML.xmlreaderElement(document, typeListe, "firstname", ItemSelect);
		String home_phone = UnparsingXML.xmlreaderElement(document, typeListe, "home_phone", ItemSelect);
		String lastname = UnparsingXML.xmlreaderElement(document, typeListe, "lastname", ItemSelect);
		String login = UnparsingXML.xmlreaderElement(document, typeListe, "login", ItemSelect);
		String phone = UnparsingXML.xmlreaderElement(document, typeListe, "phone", ItemSelect);
		String postal_code = UnparsingXML.xmlreaderElement(document, typeListe, "postal_code", ItemSelect);
		String website = UnparsingXML.xmlreaderElement(document, typeListe, "website", ItemSelect);
		
		if (typeListe.equalsIgnoreCase("music") || typeListe.equalsIgnoreCase("movie")) {
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblUrl"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField(urlItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);
		} 
		else if (typeListe.equalsIgnoreCase("picture")) 
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblUrl"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField(urlItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);
		} 
		else if (typeListe.equalsIgnoreCase("bookmark")) 
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language.getAnInternationalizeString("AjoutItem_lbllink"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField(urlItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);

			lblTag = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTag"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTag, contraintes);

			txtTag = new JTextArea(5, 20);
			txtTag.setText(TagsItem);
			ascenseur = new JScrollPane(txtTag);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblImage = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblImage"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 14; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblImage, contraintes);

			txtImage = new JTextField(ImageItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 14; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtImage, contraintes);
		} 
		else if (typeListe.equalsIgnoreCase("envie")) 
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);
		} 
		else if (typeListe.equalsIgnoreCase("recall")) 
		{
			System.out.println("rappel");
		} 
		else if (typeListe.equalsIgnoreCase("document")) 
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language.getAnInternationalizeString("AjoutItem_lbllink"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);

		} 
		else if (typeListe.equalsIgnoreCase("event")) 
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblDateDebut = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDateDebut"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateDebut, contraintes);

			txtDateDebut = new JTextField(DateDebutItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateDebut, contraintes);

			lblDateFin = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDateFin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateFin, contraintes);

			txtDateFin = new JTextField(DatefinItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateFin, contraintes);

			lblLocation = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblLocation"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblLocation, contraintes);

			txtLocation = new JTextField(LocationItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtLocation, contraintes);
			
		} 
		else if (typeListe.equalsIgnoreCase("directory")) 
		{
			lblFirstname = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblfirstname"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 0; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblFirstname, contraintes);

			txtFirstname = new JTextField(firstname);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 0; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtFirstname, contraintes);

			lbllastname = new JLabel(Language.getAnInternationalizeString("AjoutItem_lbllastname"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lbllastname, contraintes);

			txtlastname = new JTextField(lastname);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtlastname, contraintes);

			lbllogin = new JLabel(Language.getAnInternationalizeString("AjoutItem_lbllogin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lbllogin, contraintes);

			txtlogin = new JTextField(login);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtlogin, contraintes);

			lblAddress = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblAddress"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 4; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblAddress, contraintes);

			txtAddress = new JTextArea(5, 20);
			txtAddress.setText(address);
			ascenseur = new JScrollPane(txtAddress);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 4; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblpostal_code = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblpostal_code"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblpostal_code, contraintes);

			txtpostal_code = new JTextField(postal_code);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtpostal_code, contraintes);

			lblcity = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblcity"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblcity, contraintes);

			txtcity = new JTextField(city);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtcity, contraintes);

			lblcountry = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblcountry"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 11; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblcountry, contraintes);

			txtcountry = new JTextField(country);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 11; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtcountry, contraintes);

			lblEmail = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblEmail"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 12; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblEmail, contraintes);

			txtEmail = new JTextField(email);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 12; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtEmail, contraintes);

			lblEmail2 = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblEmail"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 13; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblEmail2, contraintes);

			txtEmail2 = new JTextField(email2);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 13; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtEmail2, contraintes);

			lblHome_phone = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblhome_phone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 14; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblHome_phone, contraintes);

			txtHome_phone = new JTextField(home_phone);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 14; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtHome_phone, contraintes);

			lblphone = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblphone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 15; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblphone, contraintes);

			txtphone = new JTextField(phone);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 15; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtphone, contraintes);

			lblBusiness_phone = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblBusiness_phone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 16; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblBusiness_phone, contraintes);

			txtBusiness_phone = new JTextField(business_phone);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 16; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtBusiness_phone, contraintes);

			lblWebsite = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblWebsite"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 17; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblWebsite, contraintes);

			txtWebsite = new JTextField(website);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 17; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtWebsite, contraintes);
		}
		else if (typeListe.equalsIgnoreCase("todo"))
		{
			lblTitre = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 0; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField(TitleItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 0; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 1; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			txtDescription.setText(DescriptionItem);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 1; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblDateFin = new JLabel(Language.getAnInternationalizeString("AjoutItem_lblDateFin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 6; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateFin, contraintes);

			txtDateFin = new JTextField(DatefinItem);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 6; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateFin, contraintes);

		}

		// bouton valider
		btnValider = new JButton(Language.getAnInternationalizeString("addListe_btnValider"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 18; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnValider, contraintes);
		btnValider.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 450);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		if (evt.getSource() == btnValider) {
			// Test existance du fichier
			File userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
			if (userFile.exists() == true) {
				// On cr�e une instance de SAXBuilder
				SAXReader sxr = new SAXReader();
				// On cr�e un nouveau document JDOM avec en argument le fichier
				// XML
				// Le parsing est termin�
				try {
					document = sxr.read(userFile);
					List<Node> nodes;
					nodes = document.selectNodes("//Listes/List/" + typeListe);
					for (Node node : nodes) {
						String name = node.valueOf("lastname") + " " + node.valueOf("firstname");
						if (node.valueOf("title").equals(ItemSelect) || name.equals(ItemSelect)) {
							// Cr�ation des champs en fonction du type de liste
							if (typeListe.equalsIgnoreCase("music")) {
								Element music = (Element) node;
								Element title = music.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = music
										.element("description");
								description.setText(txtDescription.getText()
										.toString());
								boolean isURL = UnparsingXML.isURL(txtUrl
										.getText().toString());
								if (isURL == true) 
								{
									Error = false;
									Element url = music.element("url");
									url.setText(txtUrl.getText().toString());
								} 
								else 
								{
									JOptionPane.showMessageDialog(null, "Erreur sur l'url.", "Erreur", JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							} 
							else if (typeListe.equalsIgnoreCase("movie")) 
							{
								Element film = (Element) node;
								Element title = film.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = film
										.element("description");
								description.setText(txtDescription.getText()
										.toString());
								boolean isURL = UnparsingXML.isURL(txtUrl
										.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = film.element("url");
									url.setText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null,
											"Erreur sur l'url.", "Erreur",
											JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							} else if (typeListe.equalsIgnoreCase("envie")) {
								Element envie = (Element) node;
								Element title = envie.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = envie
										.element("description");
								description.setText(txtDescription.getText()
										.toString());
							} else if (typeListe.equalsIgnoreCase("bookmark")) {
								Element favoris = (Element) node;
								Element title = favoris.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = favoris
										.element("description");
								description.setText(txtDescription.getText()
										.toString());
								boolean isURL = UnparsingXML.isURL(txtUrl
										.getText().toString());
								if (isURL == true) {
									Error = false;
									Element link = favoris.element("link");
									link.setText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null,
											"Erreur sur l'url.", "Erreur",
											JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
								Element picture = favoris.element("picture");
								picture.setText(txtImage.getText().toString());
								Element tags = favoris.element("tags");
								tags.setText(txtTag.getText().toString());
							} else if (typeListe.equalsIgnoreCase("picture")) {
								Element photo = (Element) node;
								Element title = photo.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = photo
										.element("description");
								description.setText(txtDescription.getText()
										.toString());
								boolean isURL = UnparsingXML.isURL(txtUrl
										.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = photo.element("url");
									url.setText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null, "Erreur sur l'url.", "Erreur", JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
								Element url_new = photo.element("url_new");
							} 
							else if (typeListe.equalsIgnoreCase("recall")) 
							{
								Element rappel = (Element) node;
								// Element title = rappel.element("title");
								// title.setText(txtTitre.getText().toString());
							} 
							else if (typeListe.equalsIgnoreCase("document")) 
							{
								Element doc = (Element) node;
								Element title = doc.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = doc.element("description");
								description.setText(txtDescription.getText().toString());
							} 
							else if (typeListe.equalsIgnoreCase("event")) {
								Element evenement = (Element) node;
								Element title = evenement.element("title");
								title.setText(txtTitre.getText().toString());
								Element description = evenement.element("description");
								description.setText(txtDescription.getText().toString());
								Element location = evenement.element("location");
								location.setText(txtLocation.getText().toString());
								boolean isDateDebut = UnparsingXML.isDate(txtDateDebut.getText().toString());
								if (isDateDebut == true) {
									Error = false;
									Element date_begin = evenement.element("date_begin");
									date_begin.setText(txtDateDebut.getText().toString());
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de d�but.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
								boolean isDateEnd = UnparsingXML.isDate(txtDateFin.getText().toString());
								if (isDateEnd == true) {
									Element date_end = evenement.element("date_end");
									date_end.setText(txtDateFin.getText().toString());
									Error = false;
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de fin.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
							} 
							else if (typeListe.equalsIgnoreCase("directory")) 
							{
								Element directory = (Element) node;
								Element item_idItem = directory.element("item_idItem");
								Element address = directory.element("address");
								address.setText(txtAddress.getText().toString());
								Element login = directory.element("login");
								login.setText(txtlogin.getText().toString());
								Element business_phone = directory.element("business_phone");
								business_phone.setText(txtBusiness_phone.getText().toString());
								Element city = directory.element("city");
								city.setText(txtcity.getText().toString());
								Element country = directory.element("country");
								country.setText(txtcountry.getText().toString());
								Element email = directory.element("email");
								email.setText(txtEmail.getText().toString());
								Element email2 = directory.element("email2");
								email2.setText(txtEmail2.getText().toString());
								Element firstname = directory.element("firstname");
								firstname.setText(txtFirstname.getText().toString());
								Element home_phone = directory.element("home_phone");
								home_phone.setText(txtHome_phone.getText().toString());
								Element lastname = directory.element("lastname");
								lastname.setText(txtlastname.getText().toString());
								Element phone = directory.element("phone");
								phone.setText(txtphone.getText().toString());
								Element postal_code = directory.element("postal_code");
								postal_code.setText(txtpostal_code.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtWebsite.getText().toString());
								if (isURL == true) {
									Error = false;
									Element website = directory.element("website");
									website.setText(txtWebsite.getText().toString());
								} 
								else 
								{
									JOptionPane.showMessageDialog(null, "Erreur sur le site web.", "Erreur", JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							}
							else if (typeListe.equalsIgnoreCase("todo")) {
								Element todo = (Element) node;
								Element item_idItem = todo.element("item_idItem");
								Element description = todo.element("description");
								description.setText(txtDescription.getText().toString());
								Element title = todo.element("title");
								title.setText(txtTitre.getText().toString());
								boolean isDateDebut = UnparsingXML.isDate(txtDateFin.getText().toString());
								if (isDateDebut == true) {
									Error = false;
									Element date_begin = todo.element("due_date");
									date_begin.setText(txtDateFin.getText().toString());
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de d�but.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
								Element check = todo.element("check");
								check.setText("false");
							}
						}
					}
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				// Message d'erreur :
				JOptionPane.showMessageDialog(null, "Cr�ez d'abord une liste.", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			if (Error == false) {
				// cr�ation du fichier
				try {
					// FileWriter myFile = new FileWriter(new File("xml/liste-"
					// + userC.get("login").toString(); + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-" + userC.get("login").toString() + ".xml"));
					XMLWriter output = new XMLWriter(myFile);
					output.write(document);
					output.close();
				} 
				catch (IOException e) {
					System.out.println(e.getMessage());
				}
				// Fermeture de la forme.
				JOptionPane.showMessageDialog(null, "Votre item a bien �t� modifier. Il sera effectif lors de la prochaine synchronisation.", "Information", JOptionPane.INFORMATION_MESSAGE);

				// Actualisation de l'accueil
				try {
					Accueil acc = new Accueil(userC);
					// Fermeture de la fenetre
					this.dispose();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fen�tre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour d�charger la m�moire occup�e par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
