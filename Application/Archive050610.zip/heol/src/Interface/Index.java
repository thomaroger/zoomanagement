package Interface;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.dom4j.DocumentException;

import Entities.Identification;
import Language.Language;
import de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaMauveMetallicLookAndFeel;

public class Index extends JFrame implements ActionListener {

	protected JLabel lblLogin;
	protected JLabel lblPassword;
	protected JTextField txtLogin;
	protected JPasswordField txtPassword;
	protected JButton btnIdentification;
	protected JButton btnClose;
	protected JPanel pnlConteneur_main;

	public Index(String title) {
		super(title);

		pnlConteneur_main = (JPanel) this.getContentPane();
		pnlConteneur_main.setLayout(new GridLayout(3, 2));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		lblLogin = new JLabel(Language
				.getAnInternationalizeString("LoginFrame_lblLogin"),
				JLabel.LEFT);
		txtLogin = new JTextField();
		lblPassword = new JLabel(Language
				.getAnInternationalizeString("LoginFrame_lblPassword"),
				JLabel.LEFT);
		txtPassword = new JPasswordField();

		btnIdentification = new JButton(Language
				.getAnInternationalizeString("LoginFrame_btnConnection"));
		btnClose = new JButton(Language
				.getAnInternationalizeString("LoginFrame_btnQuitter"));

		// Ajout des label et textfield
		pnlConteneur_main.add(lblLogin);
		pnlConteneur_main.add(txtLogin);
		pnlConteneur_main.add(lblPassword);
		pnlConteneur_main.add(txtPassword);

		// Ajout des boutons
		pnlConteneur_main.add(btnClose);
		pnlConteneur_main.add(btnIdentification);

		// Action lies aux boutons
		btnIdentification.addActionListener(this);
		btnClose.addActionListener(this);

		// Taille de la fenetre
		this.setSize(350, 127);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent evt) {
		// On charge le skin du user
		String skinName = null;
		try {
			File userFile = new File("config/Skin-"
					+ txtLogin.getText().toString() + ".txt");
			if (userFile.exists() == true) {
				InputStream ips = new FileInputStream(userFile);
				InputStreamReader ipsr = new InputStreamReader(ips);
				BufferedReader br = new BufferedReader(ipsr);
				String ligne;
				while ((ligne = br.readLine()) != null) {
					skinName = ligne;
				}
				br.close();
			}

			// On charge le skin contenu dans le fichier ou par d�faut
			// Synthetica Look & Feel
			if ("BlueMoon".equals(skinName)) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlueMoonLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if ("MauveMetallic".equals(skinName)) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaMauveMetallicLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if ("BlackStar".equals(skinName)) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlackStarLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if ("BlackMoon".equals(skinName)) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlackMoonLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if ("BlueSteel".equals(skinName)) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlueSteelLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlueSteelLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			// take an appropriate action here

		}

		if (evt.getSource() == btnIdentification) {
			Hashtable<String, String> recap = new Hashtable<String, String>();
			recap.put("login", txtLogin.getText());
			recap.put("password", txtPassword.getText());
			try {
				@SuppressWarnings("unused")
				Identification identification = new Identification(recap, this);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			this.dispose();
		}
	}

	public static void main(String[] args) {
		// Initialisation du langage
		Language.initializeLanguage();
		try {

			// fichier wsdl pour creer WS
			// http://localhost:8080/HeolWS/XMLParser?wsdl

			Index intro = new Index(Language
					.getAnInternationalizeString("LoginFrame_Title"));
		} catch (Exception ex) {
			// TODO handle custom exceptions here
			System.out.println(ex);
		}
	}
}
