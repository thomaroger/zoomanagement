package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import Entities.UnparsingXML;
import Language.Language;

@SuppressWarnings("serial")
public class AjoutItem extends JFrame implements ActionListener, WindowListener {

	private JButton btnValider;
	private JLabel lblDateDebut, lblDateFin, lblDescription, lblUrl, lblTitre, lblTag, lblImage, lblLocation, lblHome_phone;
	private JLabel lblBusiness_phone, lblAddress, lblcountry, lblcity, lblEmail, lblEmail2, lblFirstname;
	private JLabel lblpostal_code, lbllastname, lbllogin, lblphone, lblWebsite;
	private JTextField txtDateDebut, txtDateFin, txtUrl, txtTitre, txtImage, txtLocation, txtHome_phone;
	private JTextField txtBusiness_phone, txtcountry, txtcity, txtEmail, txtEmail2, txtFirstname;
	private JTextField txtpostal_code, txtlastname, txtlogin, txtphone, txtWebsite;
	private JTextArea txtDescription, txtTag, txtAddress;
	private JScrollPane ascenseur;
	private JPanel pnlConteneur_main;

	boolean Error = false;

	// Utilisateur courant
	protected Hashtable<String, String> userC;

	private String ListeSelectionne, typeListe;

	private Document document = null;
	private File userFile;

	public AjoutItem(String titre, Hashtable<String, String> user,
			String ListeSelecte) throws DocumentException {
		super(titre);

		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);

		// Utilisateur courant
		userC = user;

		// Type de Liste selectionnee
		ListeSelectionne = ListeSelecte;

		// Conteneur principale
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// Suppression des composants présents sur la forme
		if (pnlConteneur_main.getComponentCount() > 0) {
			for (int i = 0; i < pnlConteneur_main.getComponentCount(); i++) {
				pnlConteneur_main.remove(i);
			}
		}

		// Récupération du model de liste sélectionnée
		userFile = new File("xml/liste-" + userC.get("login").toString()
				+ ".xml");
		if (userFile.exists() == true) {
			SAXReader sxr = new SAXReader();
			document = sxr.read(userFile);
			typeListe = UnparsingXML.selectCategorie(document, ListeSelecte);
		}

		if (typeListe.equalsIgnoreCase("music")
				|| typeListe.equalsIgnoreCase("movie")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblUrl"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);
		} else if (typeListe.equalsIgnoreCase("picture")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblUrl"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);
		} else if (typeListe.equalsIgnoreCase("bookmark")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lbllink"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);

			lblTag = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTag"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTag, contraintes);

			txtTag = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtTag);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblImage = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblImage"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 14; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblImage, contraintes);

			txtImage = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 14; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtImage, contraintes);
		} else if (typeListe.equalsIgnoreCase("envie")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);
		} else if (typeListe.equalsIgnoreCase("recall")) {
			System.out.println("rappel");
		} else if (typeListe.equalsIgnoreCase("document")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblUrl = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lbllink"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblUrl, contraintes);

			txtUrl = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtUrl, contraintes);

		} else if (typeListe.equalsIgnoreCase("event")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblDateDebut = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDateDebut"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateDebut, contraintes);

			txtDateDebut = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateDebut, contraintes);

			lblDateFin = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDateFin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateFin, contraintes);

			txtDateFin = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateFin, contraintes);

			lblLocation = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblLocation"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblLocation, contraintes);

			txtLocation = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtLocation, contraintes);
		} else if (typeListe.equalsIgnoreCase("todo")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 0; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 0; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 1; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 1; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblDateFin = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDateFin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 6; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateFin, contraintes);

			txtDateFin = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 6; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateFin, contraintes);

		} else if (typeListe.equalsIgnoreCase("event")) {
			lblTitre = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblTitre"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblTitre, contraintes);

			txtTitre = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtTitre, contraintes);

			lblDescription = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDescription"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblDescription, contraintes);

			txtDescription = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtDescription);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblDateDebut = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDateDebut"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateDebut, contraintes);

			txtDateDebut = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 8; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateDebut, contraintes);

			lblDateFin = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblDateFin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblDateFin, contraintes);

			txtDateFin = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtDateFin, contraintes);

			lblLocation = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblLocation"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblLocation, contraintes);

			txtLocation = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtLocation, contraintes);
		} else if (typeListe.equalsIgnoreCase("directory")) {
			lblFirstname = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblfirstname"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 0; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblFirstname, contraintes);

			txtFirstname = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 0; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtFirstname, contraintes);

			lbllastname = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lbllastname"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 2; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lbllastname, contraintes);

			txtlastname = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 2; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtlastname, contraintes);

			lbllogin = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lbllogin"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 3; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lbllogin, contraintes);

			txtlogin = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 3; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtlogin, contraintes);

			lblAddress = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblAddress"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 4; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblAddress, contraintes);

			txtAddress = new JTextArea(5, 20);
			ascenseur = new JScrollPane(txtAddress);
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 4; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 5; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(ascenseur, contraintes);

			lblpostal_code = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblpostal_code"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblpostal_code, contraintes);

			txtpostal_code = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 9; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtpostal_code, contraintes);

			lblcity = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblcity"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblcity, contraintes);

			txtcity = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 10; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtcity, contraintes);

			lblcountry = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblcountry"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 11; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblcountry, contraintes);

			txtcountry = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 11; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtcountry, contraintes);

			lblEmail = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblEmail"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 12; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblEmail, contraintes);

			txtEmail = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 12; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtEmail, contraintes);

			lblEmail2 = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblEmail"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 13; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblEmail2, contraintes);

			txtEmail2 = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 13; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtEmail2, contraintes);

			lblHome_phone = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblhome_phone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 14; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblHome_phone, contraintes);

			txtHome_phone = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 14; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtHome_phone, contraintes);

			lblphone = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblphone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 15; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblphone, contraintes);

			txtphone = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 15; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtphone, contraintes);

			lblBusiness_phone = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblBusiness_phone"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 16; // ligne 1
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(lblBusiness_phone, contraintes);

			txtBusiness_phone = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 16; // ligne 1
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 3 lignes
			pnlConteneur_main.add(txtBusiness_phone, contraintes);

			lblWebsite = new JLabel(Language
					.getAnInternationalizeString("AjoutItem_lblWebsite"));
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 0; // colonne 0
			contraintes.gridy = 17; // ligne 0
			contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(lblWebsite, contraintes);

			txtWebsite = new JTextField();
			contraintes.fill = GridBagConstraints.HORIZONTAL;
			contraintes.anchor = GridBagConstraints.NORTH;
			contraintes.weightx = 1.0;
			contraintes.weighty = 1.0;
			contraintes.gridx = 1; // colonne 0
			contraintes.gridy = 17; // ligne 0
			contraintes.gridwidth = 2; // le composant s'etend sur 1 colonne
			contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
			pnlConteneur_main.add(txtWebsite, contraintes);
		}

		// bouton valider
		btnValider = new JButton(Language
				.getAnInternationalizeString("addListe_btnValider"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 18; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnValider, contraintes);
		btnValider.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 450);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);

	}

	@SuppressWarnings("unchecked")
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource() == btnValider) {
			// Test existance du fichier
			File userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
			if (userFile.exists() == true) {
				// On crée une instance de SAXBuilder
				SAXReader sxr = new SAXReader();
				// On crée un nouveau document JDOM avec en argument le fichier
				// XML
				// Le parsing est terminé
				try {
					document = sxr.read(userFile);
					document.setXMLEncoding("UTF-8");
					List<Node> nodes;
					nodes = document.selectNodes("//Listes/List");
					for (Node node : nodes) {
						if (node.valueOf("title").equals(ListeSelectionne)) {
							// Création des champs en fonction du type de liste
							if (typeListe.equalsIgnoreCase("music")) 
							{
								Element racine = (Element) node;
								Element typeListe = racine.addElement("music");
								Element item_idItem = typeListe.addElement("item_idItem");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtUrl.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = typeListe.addElement("url");
									url.addText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null, "Erreur sur l'url.", "Erreur", JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							} else if (typeListe.equalsIgnoreCase("movie")) {
								Element racine = (Element) node;
								Element typeListe = racine.addElement("movie");
								Element item_idItem = typeListe.addElement("item_idItem");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtUrl.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = typeListe.addElement("url");
									url.addText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null, "Erreur sur l'url.", "Erreur", JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							} else if (typeListe.equalsIgnoreCase("envie")) {
								Element racine = (Element) node;
								Element typeListe = racine.addElement("envie");
								Element item_idItem = typeListe.addElement("item_idItem");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
							} else if (typeListe.equalsIgnoreCase("favoris")) {
								Element racine = (Element) node;
								Element typeListe = racine
								.addElement("bookmark");
								Element item_idItem = typeListe
								.addElement("item_idItem");
								Element description = typeListe
								.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtUrl.getText().toString());
								if (isURL == true) {
									Error = false;
									Element link = typeListe.addElement("link");
									link.addText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null,
											"Erreur sur l'url.", "Erreur",
											JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
								Element picture = typeListe.addElement("picture");
								picture.addText(txtImage.getText().toString());
								Element tags = typeListe.addElement("tags");
								tags.addText(txtTag.getText().toString());
							} else if (typeListe.equalsIgnoreCase("picture")) {
								Element racine = (Element) node;
								Element typeListe = racine
								.addElement("picture");
								Element item_idItem = typeListe
								.addElement("item_idItem");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtUrl.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = typeListe.addElement("url");
									url.addText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null,
											"Erreur sur l'url.", "Erreur",
											JOptionPane.ERROR_MESSAGE);
									Error = true;
								}

								Element url_new = typeListe
								.addElement("url_new");
							} else if (typeListe.equalsIgnoreCase("recall")) {
								Element racine = (Element) node;
								Element typeListe = racine.addElement("Rappel");
								Element item_idItem = typeListe
								.addElement("item_idItem");
								item_idItem.addText("1");
							} else if (typeListe.equalsIgnoreCase("document")) {
								Element racine = (Element) node;
								Element typeListe = racine
								.addElement("document");
								Element item_idItem = typeListe
								.addElement("item_idItem");
								Element description = typeListe
								.addElement("description");
								description.addText(txtDescription.getText()
										.toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isURL = UnparsingXML.isURL(txtUrl.getText().toString());
								if (isURL == true) {
									Error = false;
									Element url = typeListe.addElement("url");
									url.addText(txtUrl.getText().toString());
								} else {
									JOptionPane.showMessageDialog(null,
											"Erreur sur l'url.", "Erreur",
											JOptionPane.ERROR_MESSAGE);
									Error = true;
								}
							} else if (typeListe.equalsIgnoreCase("event")) {
								Element racine = (Element) node;
								Element typeListe = racine.addElement("event");
								Element item_idItem = typeListe.addElement("item_idItem");
								item_idItem.addText("1");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								Element location = typeListe.addElement("location");
								location.addText(txtLocation.getText().toString());
								boolean isDateDebut = UnparsingXML.isDate(txtDateDebut.getText().toString());
								if (isDateDebut == true) {
									Error = false;
									Element date_begin = typeListe.addElement("date_begin");
									date_begin.addText(txtDateDebut.getText().toString());
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de début.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
								boolean isDateEnd = UnparsingXML.isDate(txtDateFin.getText().toString());
								if (isDateEnd == true) {
									Element date_end = typeListe.addElement("date_end");
									date_end.addText(txtDateFin.getText().toString());
									Error = false;
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de fin.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
							} 
							else if (typeListe.equalsIgnoreCase("directory")) 
							{
								Element racine = (Element) node;
								Element typeListe = racine.addElement("directory");
								Element item_idItem = typeListe.addElement("item_idItem");
								Element address = typeListe.addElement("address");
								address.addText(txtAddress.getText().toString());
								Element login = typeListe.addElement("login");
								login.addText(txtlogin.getText().toString());
								Element business_phone = typeListe.addElement("business_phone");
								business_phone.addText(txtBusiness_phone.getText().toString());
								Element city = typeListe.addElement("city");
								city.addText(txtcity.getText().toString());
								Element country = typeListe.addElement("country");
								country.addText(txtcountry.getText().toString());
								Element email = typeListe.addElement("email");
								email.addText(txtEmail.getText().toString());
								Element email2 = typeListe.addElement("email2");
								email2.addText(txtEmail2.getText().toString());
								Element firstname = typeListe.addElement("firstname");
								firstname.addText(txtFirstname.getText().toString());
								Element home_phone = typeListe.addElement("home_phone");
								home_phone.addText(txtHome_phone.getText().toString());
								Element lastname = typeListe.addElement("lastname");
								lastname.addText(txtlastname.getText().toString());
								Element phone = typeListe.addElement("phone");
								phone.addText(txtphone.getText().toString());
								Element postal_code = typeListe.addElement("postal_code");
								postal_code.addText(txtpostal_code.getText().toString());
								if (!txtWebsite.getText().toString().isEmpty()) {
									boolean isURL = UnparsingXML.isURL(txtWebsite.getText().toString());
									if (isURL == true) {
										Error = false;
										Element website = typeListe.addElement("website");
										website.addText(txtWebsite.getText().toString());
									} else {
										JOptionPane.showMessageDialog(null, "Erreur sur le site web.", "Erreur", JOptionPane.ERROR_MESSAGE);
										Error = true;
									}
								}
								else
								{
									Element website = typeListe.addElement("website");
								}
									
							}
							else if (typeListe.equalsIgnoreCase("todo")) {
								Element racine = (Element) node;
								Element typeListe = racine.addElement("todo");
								Element item_idItem = typeListe.addElement("item_idItem");
								item_idItem.addText("1");
								Element description = typeListe.addElement("description");
								description.addText(txtDescription.getText().toString());
								Element title = typeListe.addElement("title");
								title.addText(txtTitre.getText().toString());
								boolean isDateDebut = UnparsingXML.isDate(txtDateFin.getText().toString());
								if (isDateDebut == true) {
									Error = false;
									Element date_begin = typeListe.addElement("due_date");
									date_begin.addText(txtDateFin.getText().toString());
								} else {
									Error = true;
									JOptionPane.showMessageDialog(null, "Erreur sur la date de début.", "Erreur", JOptionPane.ERROR_MESSAGE);
								}
								Element check = typeListe.addElement("check");
								check.addText("false");
							}
						}
					}
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				// Message d'erreur :
				JOptionPane.showMessageDialog(null, "Créez d'abord une liste.", "Erreur", JOptionPane.ERROR_MESSAGE);
			}

			if (Error == false) {
				// création du fichier
				try {
					// FileWriter myFile = new FileWriter(new File("xml/liste-"
					// + userC.get("login").toString(); + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-" + userC.get("login").toString() + ".xml"));
					XMLWriter output = new XMLWriter(myFile);
					output.write(document);
					output.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
				// Fermeture de la forme.
				JOptionPane.showMessageDialog(null, "Votre item a bien été ajouté. Il sera effectif lors de la prochaine synchronisation.", "Information", JOptionPane.INFORMATION_MESSAGE);

				// Actualisation de l'accueil
				try {
					Accueil acc = new Accueil(userC);
					// Fermeture de la fenetre
					this.dispose();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fenétre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour décharger la mémoire occupée par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}
}
