package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.util.Hashtable;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.xml.rpc.ServiceException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import Entities.UnparsingXML;
import Language.Language;

@SuppressWarnings("serial")
public class Accueil extends JFrame implements ActionListener {

	private JLabel lblUser, lblUserLogger, lblRecherche, lblListe, lblItem;
	private String userCo;
	private JMenu mMenu, mAPropos;
	private JMenuBar mbBarre;
	private JMenuItem miQuitter, miSynchroniser, miPerso;
	private JPanel pnlConteneur_main;
	private JButton btnAjoutListe, btnRecherche, btnModifierListe, btnSupprimerListe, btnAddItem, BtnDeleteItem, BtnModifyItem;
	private JList lstMesItems, lstChoixListe;
	private JTextField txtRecherche;
	private JScrollPane ascenseur, ascenseur2;

	// utilisateur courant
	private Hashtable<String, String> userC;
	private File userFile;

	// liste
	private DefaultListModel model;
	private String[] options = {};
	private String[] listeDeListe = {};
	private String typeListe = null;
	
	// Format UTF8
	private OutputFormat outFormat = new OutputFormat();

	public Accueil(Hashtable<String, String> user) throws DocumentException, UnsupportedEncodingException {
		// Titre de la fenetre
		super(Language.getAnInternationalizeString("Acceuil_Title"));

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Utilisateur courant
		userC = user;

		// Conteneur principal
		pnlConteneur_main = (JPanel) new JPanel();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();

		// Ajout du menu
		// Creation de la barre
		mbBarre = new JMenuBar();
		// Creation du menu
		mMenu = new JMenu(Language.getAnInternationalizeString("Accueil_MenuF"));
		mAPropos = new JMenu(Language.getAnInternationalizeString("Accueil_MenuAP"));
		// Creation sous menu
		miQuitter = new JMenuItem(Language.getAnInternationalizeString("Accueil_SMenuF2"));
		miQuitter.addActionListener(this);
		miSynchroniser = new JMenuItem(Language.getAnInternationalizeString("Accueil_SMenuF3"));
		miSynchroniser.addActionListener(this);
		miPerso = new JMenuItem(Language.getAnInternationalizeString("Accueil_SMenuF4"));
		miPerso.addActionListener(this);
		// Ajout du menu é la barre
		mbBarre.add(mMenu);
		mbBarre.add(mAPropos);
		// Ajout sous menu au menu
		mMenu.add(miQuitter);
		mAPropos.add(miSynchroniser);
		mAPropos.add(miPerso);
		// Ajout du menu
		setJMenuBar(mbBarre);

		// Ajout du label Recherche
		lblRecherche = new JLabel(Language.getAnInternationalizeString("Accueil_Recherche"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.CENTER;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblRecherche, contraintes);

		// Ajout de la textbox de recherche
		txtRecherche = new JTextField();
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.CENTER;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(txtRecherche, contraintes);

		// Ajout bouton recherche
		btnRecherche = new JButton(Language.getAnInternationalizeString("Accueil_btnRecherche"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.CENTER;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 2; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnRecherche, contraintes);
		btnRecherche.addActionListener(this);

		// Ajout label User
		lblUser = new JLabel(Language.getAnInternationalizeString("Accueil_User"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 1; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblUser, contraintes);

		// Ajout label UserCo
		userCo = userC.get("login").toString();
		lblUserLogger = new JLabel(userCo);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 1
		contraintes.gridy = 1; // ligne 1
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblUserLogger, contraintes);

		// Lecture du XML de l'utilisateur pour ces listes
		userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
		if (userFile.exists() == true) {
			SAXReader sxr = new SAXReader();
			Document document = sxr.read(userFile);
			document.setXMLEncoding("UTF-8");
			listeDeListe = UnparsingXML.xmlreaderListe(document, null, "title");
		}

		// Ajout label Liste
		lblListe = new JLabel(Language.getAnInternationalizeString("Accueil_lblListe"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 2; // ligne 2
		contraintes.gridwidth = 3; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblListe, contraintes);

		// Ajout de toutes liste dispo
		lstChoixListe = new JList(listeDeListe);
		ascenseur = new JScrollPane(lstChoixListe);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 3; // ligne 1
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 6; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur, contraintes);
		lstChoixListe.addListSelectionListener(new choixItem());

		// Ajout du bouton pour creer une nouvelle liste
		btnAjoutListe = new JButton(Language.getAnInternationalizeString("Accueil_btnAjout"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 9; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnAjoutListe, contraintes);
		btnAjoutListe.addActionListener(this);

		// Ajout du bouton pour modifier une liste
		btnModifierListe = new JButton(Language.getAnInternationalizeString("Accueil_btnModifier"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 1; // colonne 2
		contraintes.gridy = 9; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnModifierListe, contraintes);
		btnModifierListe.addActionListener(this);

		// Ajout du bouton pour supprimer une liste
		btnSupprimerListe = new JButton(Language.getAnInternationalizeString("Accueil_btnSupprimer"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 2; // colonne 2
		contraintes.gridy = 9; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnSupprimerListe, contraintes);
		btnSupprimerListe.addActionListener(this);

		// Ajout label item
		lblItem = new JLabel(Language.getAnInternationalizeString("Accueil_lblItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 10; // ligne 2
		contraintes.gridwidth = 3; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(lblItem, contraintes);

		// Ajout de la liste des items de la liste selectionnee
		model = new DefaultListModel();
		lstMesItems = new JList(model);
		ascenseur2 = new JScrollPane(lstMesItems);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 1
		contraintes.gridy = 11; // ligne 1
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 6; // le composant s'etend sur 3 lignes
		pnlConteneur_main.add(ascenseur2, contraintes);

		// Ajout du bouton pour ajouter un item
		btnAddItem = new JButton(Language.getAnInternationalizeString("Accueil_btnAjoutItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 0; // colonne 2
		contraintes.gridy = 17; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(btnAddItem, contraintes);
		btnAddItem.addActionListener(this);

		// Ajout du bouton pour modifier un item
		BtnModifyItem = new JButton(Language.getAnInternationalizeString("Accueil_btnModifierItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 1; // colonne 2
		contraintes.gridy = 17; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(BtnModifyItem, contraintes);
		BtnModifyItem.addActionListener(this);

		// Ajout du bouton pour supprimer un item
		BtnDeleteItem = new JButton(Language.getAnInternationalizeString("Accueil_btnSupprimerItem"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.SOUTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.ipadx = 0;
		contraintes.gridx = 2; // colonne 2
		contraintes.gridy = 17; // ligne 2
		contraintes.gridwidth = 1; // le composant s'etend sur 2 colonnes
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(BtnDeleteItem, contraintes);
		BtnDeleteItem.addActionListener(this);

		// Ajout du panel
		this.add(pnlConteneur_main);

		// Taille de la fenetre
		this.setSize(500, 555);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2, (screen.height - this.getSize().height) / 2);

	}

	// Action des boutons, listes, etc
	public void actionPerformed(ActionEvent evt) {
		Document document = null;

		if (evt.getSource() == btnAddItem) {
			if (lstChoixListe.getSelectedValue() != null) {
				try {
					@SuppressWarnings("unused")
					AjoutItem addItem = new AjoutItem(Language.getAnInternationalizeString("Accueil_TitreAjouterItem"), userC, lstChoixListe.getSelectedValue().toString());
					this.dispose();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "Vous devez sélectionné une liste", "Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == btnAjoutListe) {
			try {
				@SuppressWarnings("unused")
				AjoutListe AjoutListe = new AjoutListe(Language.getAnInternationalizeString("Accueil_TitreAjoutListe"), userC);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.dispose();
		} 
		else if (evt.getSource() == btnModifierListe) 
		{
			if (lstChoixListe.getSelectedValue() != null) 
			{
				@SuppressWarnings("unused")
				ModifierListe modifieListe = new ModifierListe(Language.getAnInternationalizeString("Accueil_TitreModifierListe"), userC, lstChoixListe.getSelectedValue().toString());
				this.dispose();
			} 
			else 
			{
				JOptionPane.showMessageDialog(null, "Vous devez sélectionné une liste", "Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == BtnModifyItem) {
			if (lstChoixListe.getSelectedValue() != null && lstMesItems.getSelectedValue() != null) {
				try {
					@SuppressWarnings("unused")
					ModifierItem modifieItem = new ModifierItem(Language.getAnInternationalizeString("Accueil_TitreModifierItem"), userC, lstChoixListe.getSelectedValue().toString(), lstMesItems.getSelectedValue().toString());
					this.dispose();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "Vous devez sélectionné une liste et un item", "Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == btnSupprimerListe) {
			if (lstChoixListe.getSelectedValue() != null) {
				SAXReader sxr = new SAXReader();
				try {
					document = sxr.read(userFile);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Supression de la liste
				document = UnparsingXML.removeList(document, "title", lstChoixListe.getSelectedValue().toString());

				// Enregistrement dans le fichier xml
				try {
					// FileWriter myFile = new FileWriter(new File("xml/liste-"
					// + userC.get("login").toString(); + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-" + userC.get("login").toString() + ".xml"));
					outFormat.setEncoding("UTF-8");
					XMLWriter output = new XMLWriter(myFile, outFormat);
					output.write(document);
					output.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}

				JOptionPane.showMessageDialog(null, "Votre liste a bien été supprimée", "Information", JOptionPane.INFORMATION_MESSAGE);

				this.dispose();
				try {
					@SuppressWarnings("unused")
					Accueil acc = new Accueil(userC);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "Vous devez sélectionné une liste", "Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == BtnDeleteItem) {
			if (lstMesItems.getSelectedValue() != null && lstChoixListe.getSelectedValue() != null) {
				SAXReader sxr = new SAXReader();
				try {
					document = sxr.read(userFile);
					document.setXMLEncoding("UTF-8");
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//Enregistrement de la suppression dans un fichier texte pour synchronisation
				try 
				{
					UnparsingXML.fichierDelete(document, "title", lstMesItems.getSelectedValue().toString(), typeListe, userC);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// Supression de l'item
				document = UnparsingXML.removeItem(document, "title", lstMesItems.getSelectedValue().toString(), typeListe);
				// Enregistrement dans le fichier xml
				try {
					// FileWriter myFile = new FileWriter(new
					// File(userC.get("login").toString(); + ".xml"), true);
					FileWriter myFile = new FileWriter(new File("xml/liste-" + userC.get("login").toString() + ".xml"));
					outFormat.setEncoding("UTF-8");
					XMLWriter output = new XMLWriter(myFile, outFormat);
					output.write(document);
					output.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}

				JOptionPane.showMessageDialog(null, "Votre item a bien été supprimé", "Information", JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
				try {
					@SuppressWarnings("unused")
					Accueil acc = new Accueil(userC);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "Vous devez sélectionné une liste et un item", "Information", JOptionPane.ERROR_MESSAGE);
			}
		} else if (evt.getSource() == btnRecherche) {
			try {
				SAXReader reader = new SAXReader();
				try {
					document = reader.read(userFile);
				} catch (DocumentException ex) {
					System.out.println(ex);
				}
				// Recherche
				DefaultListModel rechercheListe = UnparsingXML.searchListe(document, txtRecherche.getText().toString());
				String[] typedeListe = {"music", "picture", "movie", "bookmark", "envie", "recall", "document", "event", "directory", "todo"};
				DefaultListModel rechercheItem = UnparsingXML.searchItem(document, txtRecherche.getText().toString(), typedeListe);
				
				@SuppressWarnings("unused")
				Recherche search = new Recherche(userC, rechercheListe, rechercheItem);
				this.dispose();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		else if (evt.getSource() == miQuitter) 
		{
			this.dispose();
		} 
		else if (evt.getSource() == miPerso)
		{
			@SuppressWarnings("unused")
			Skin sk = new Skin("Choix de votre skin", userC);
			this.dispose();
		} 
		else if (evt.getSource() == miSynchroniser) 
		{
			// Envoie sous forme de string du contenu du fichier delete-login.txt
			String listeDelete = "";
			String ligne = "";

			InputStream ips = null;
			InputStreamReader ipsr = null;
			try 
			{
				ips = new FileInputStream("xml/delete-" + userC.get("login").toString() + ".txt");
				ipsr = new InputStreamReader(ips, "UTF-8");

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BufferedReader br = new BufferedReader(ipsr);

			try 
			{
				int i = 0;
				while ((ligne = br.readLine()) != null) 
				{
					listeDelete += ligne;
					i++;
				}
				br.close();
			} catch (IOException ex) {

			}

			// Envoie sous forme de string du contenu du fichier liste-login.xml
			String xmlUser = "";
			ligne = "";

			try 
			{
				ips = new FileInputStream("xml/liste-" + userC.get("login").toString() + ".xml");
				ipsr = new InputStreamReader(ips, "UTF-8");

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			br = new BufferedReader(ipsr);

			try 
			{
				int i = 0;
				while ((ligne = br.readLine()) != null) 
				{
					xmlUser += ligne;
					i++;
				}
				br.close();
				// on supprime la dtd de la string
				xmlUser = xmlUser.substring(73, xmlUser.length());
				if(!xmlUser.startsWith("<"))
					xmlUser = "<"+ xmlUser;
			} 
			catch (IOException ex) 
			{

			}

			//récupération idUser
			File infoFile = new File("xml/info-" + userC.get("login").toString() + ".xml");
			String idUser = null;
			if (infoFile.exists() == true) {
				SAXReader reader = new SAXReader();
				document = null;
				try {
					document = reader.read(infoFile);
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				idUser = UnparsingXML.idUser(document);
			}
			
			//Connexion au webservice
			parsing.XMLParser_Service service = new parsing.XMLParser_ServiceLocator();
			parsing.XMLParser_PortType port = null;

			try
			{
				port = service.getXMLParserPort();
			}
			catch (ServiceException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Envoie les données synchroniser au WS sous forme de string
			try {
				port.unparseXML(idUser, xmlUser, listeDelete);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
	
	class choixItem implements ListSelectionListener 
	{

		public void valueChanged(ListSelectionEvent e) 
		{
			/*
			 * test sur le listener du bouton : clic souris = true relachement =
			 * false ce qui entraine 2 appels de la fonction valueChanged donc
			 * test pour seulement é true
			 */
			boolean adjust = lstChoixListe.getValueIsAdjusting();

			if (adjust == true) 
			{
				// initialisation du model
				model.clear();

				// Lecture du XML de l'utilisateur pour ces listes
				userFile = new File("xml/liste-" + userC.get("login").toString() + ".xml");
				if (userFile.exists() == true) 
				{
					SAXReader sxr = new SAXReader();
					Document document = null;
					try 
					{
						document = sxr.read(userFile);
						document.setXMLEncoding("UTF-8");
					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if (lstChoixListe.getSelectedValue() != null) 
					{
						// Récupération du nom du model
						typeListe = UnparsingXML.selectCategorie(document, lstChoixListe.getSelectedValue().toString());
						// typeListe = capitalize(typeListe);
						options = UnparsingXML.xmlreaderItem(document, typeListe, "title", lstChoixListe.getSelectedValue().toString());
						for (int i = 0; i < options.length; i++) 
						{
							model.addElement(options[i]);
						}
					}
				}
			}
		}
	}

	public static String capitalize(String s) {
		if (s.length() == 0)
			return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
	}

}
