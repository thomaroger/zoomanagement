package Interface;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.dom4j.DocumentException;

import Language.Language;
import de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel;
import de.javasoft.plaf.synthetica.SyntheticaMauveMetallicLookAndFeel;

public class Skin extends JFrame implements ActionListener, WindowListener {

	protected JLabel lblChoixSkin;
	protected JComboBox cmbSkin;
	protected JButton Valider;
	protected JPanel pnlConteneur_main;

	protected Hashtable userC;

	public Skin(String title, Hashtable user) {
		super(title);

		pnlConteneur_main = (JPanel) this.getContentPane();
		pnlConteneur_main.setLayout(new GridBagLayout());
		GridBagConstraints contraintes = new GridBagConstraints();
		this.addWindowListener(this);

		userC = user;

		String[] skin = { "BlueMoon", "MauveMetallic", "BlackStar",
				"BlackMoon", "BlueSteel" };
		cmbSkin = new JComboBox(skin);
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 0; // colonne 0
		contraintes.gridy = 0; // ligne 0
		contraintes.gridwidth = 3; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(cmbSkin, contraintes);
		cmbSkin.addActionListener(this);

		Valider = new JButton(Language
				.getAnInternationalizeString("Skin_Valider"));
		contraintes.fill = GridBagConstraints.HORIZONTAL;
		contraintes.anchor = GridBagConstraints.NORTH;
		contraintes.weightx = 1.0;
		contraintes.weighty = 1.0;
		contraintes.gridx = 1; // colonne 0
		contraintes.gridy = 1; // ligne 0
		contraintes.gridwidth = 1; // le composant s'etend sur 1 colonne
		contraintes.gridheight = 1; // le composant s'etend sur 1 ligne
		pnlConteneur_main.add(Valider, contraintes);

		// Action lies aux boutons
		Valider.addActionListener(this);

		// Taille de la fenetre
		this.setSize(350, 127);
		this.setVisible(true);
		this.setResizable(false);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screen.width - this.getSize().width) / 2,
				(screen.height - this.getSize().height) / 2);
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource() == cmbSkin) {
			if (cmbSkin.getSelectedItem().equals("BlueMoon")) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlueMoonLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (cmbSkin.getSelectedItem().equals("MauveMetallic")) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaMauveMetallicLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (cmbSkin.getSelectedItem().equals("BlackStar")) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlackStarLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (cmbSkin.getSelectedItem().equals("BlackMoon")) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlackMoonLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (cmbSkin.getSelectedItem().equals("BlueSteel")) {
				try {
					UIManager
							.setLookAndFeel(new SyntheticaBlueSteelLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else if (evt.getSource() == Valider) {
			// on sauvegarde le choix de l'utilisateur dans un fichier
			FileWriter fichier;
			try {
				fichier = new FileWriter(new File("config/Skin-"
						+ userC.get("login").toString() + ".txt"), false);
				fichier.write(cmbSkin.getSelectedItem().toString());
				fichier.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				Accueil acc = new Accueil(userC);
				// fermeture de la fenetre
				this.dispose();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		// code pour afficher ta fen�tre
		try {
			Accueil acc = new Accueil(userC);
			this.dispose(); // pour d�charger la m�moire occup�e par ta feuille
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}
}
