package Entities;

public class User_has_list {

	private int user_idUser, list_idList;

	public void setUser_idUser(int user_idUser) {
		this.user_idUser = user_idUser;
	}

	public int getUser_idUser() {
		return user_idUser;
	}

	public void setList_idList(int list_idList) {
		this.list_idList = list_idList;
	}

	public int getList_idList() {
		return list_idList;
	}
}
