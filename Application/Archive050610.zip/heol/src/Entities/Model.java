package Entities;

public class Model {

	private int idModel;
	private int islist;
	private String libelle_fr;
	private String libelle_en;
	private int model_id;
	private String table_name;

	public void setIdModel(int idModel) {
		this.idModel = idModel;
	}

	public int getIdModel() {
		return idModel;
	}

	public void setLibelle_fr(String libelle_fr) {
		this.libelle_fr = libelle_fr;
	}

	public String getLibelle_fr() {
		return libelle_fr;
	}

	public void setLibelle_en(String libelle_en) {
		this.libelle_en = libelle_en;
	}

	public String getLibelle_en() {
		return libelle_en;
	}

	public void setModel_id(int model_id) {
		this.model_id = model_id;
	}

	public int getModel_id() {
		return model_id;
	}

	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}

	public String getTable_name() {
		return table_name;
	}

	public void setIslist(int islist) {
		this.islist = islist;
	}

	public int getIslist() {
		return islist;
	}

}
