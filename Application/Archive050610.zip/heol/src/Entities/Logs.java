package Entities;

public class Logs {

	protected int Id, usersId;
	protected String Date, Type, Description;

	public Logs() {
	}

	public void setId(int i) {
		this.Id = i;
	}

	public int getId() {
		return this.Id;
	}

	public void setUsersId(int j) {
		this.usersId = j;
	}

	public int getUsersId() {
		return this.usersId;
	}

	public void setDate(String k) {
		this.Date = k;
	}

	public String getDate() {
		return this.Date;
	}

	public void setType(String l) {
		this.Type = l;
	}

	public String getType() {
		return this.Type;
	}

	public void setDescription(String m) {
		this.Description = m;
	}

	public String getDescription() {
		return this.Description;
	}
}