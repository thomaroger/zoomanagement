/**
 * XMLParser_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package parsing;

public interface XMLParser_PortType extends java.rmi.Remote {
    public void unparseXML(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException;
    public java.lang.Object[][] xmlParserUser(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException;
    public java.lang.Object[][] xmlParser(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException;
    public java.lang.String xmlParserList(java.lang.String arg0) throws java.rmi.RemoteException;
    public java.lang.String[] recupTypeList() throws java.rmi.RemoteException;
    public java.lang.String[] recupTypeCategorie() throws java.rmi.RemoteException;
}
